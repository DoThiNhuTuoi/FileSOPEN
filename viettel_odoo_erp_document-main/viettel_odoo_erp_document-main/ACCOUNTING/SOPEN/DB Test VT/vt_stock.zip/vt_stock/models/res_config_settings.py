# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    is_delivery_more_than_available = fields.Boolean(string='Delivery more than available')
    is_purchase_order_as_receipt = fields.Boolean(string='Purchase Order As Receipt')

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        self.env.company.write({
            'is_delivery_more_than_available': self.is_delivery_more_than_available,
            'is_purchase_order_as_receipt': self.is_purchase_order_as_receipt
        })
        return res

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            is_delivery_more_than_available=self.env.company.is_delivery_more_than_available,
            is_purchase_order_as_receipt=self.env.company.is_purchase_order_as_receipt
        )
        return res
