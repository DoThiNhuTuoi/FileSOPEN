# -*- coding: utf-8 -*-

from odoo import _, models, fields, api


class AccountConstruction(models.Model):
    _inherit = "account.construction"

    def name_get(self):
        result = []
        for po in self:
            name = po.name + ' - ' + str(po.date_order.date())
            result.append((po.id, name))
        return result