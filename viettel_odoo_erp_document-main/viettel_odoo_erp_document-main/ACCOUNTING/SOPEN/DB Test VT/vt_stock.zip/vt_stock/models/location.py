# -*- coding: utf-8 -*-


from odoo import models, fields


class Location(models.Model):
    _inherit = "stock.location"
    branch_id = fields.Many2one('hr.department', store=True)
