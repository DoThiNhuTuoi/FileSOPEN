from odoo import models, api, fields, _


class StockInventoryParticipants(models.Model):
    _name = 'stock.inventory.participants'

    company_id = fields.Many2one(
        'res.company', 'Company',
        readonly=True, index=True, required=True,
        default=lambda self: self.env.company)

    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                related='inventory_id.branch_id',
                                required=True, store=True)
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    related='inventory_id.department_id',
                                    required=True, store=True)
    employee_id = fields.Many2one('hr.employee', domain=[('active', '=', True)], required=True)
    job_title = fields.Text(string='Job Position')
    represent = fields.Text(string='Represent')
    inventory_id = fields.Many2one(
        'stock.inventory', 'Inventory', check_company=True,
        index=True, ondelete='cascade')

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        self.job_title = self.employee_id.job_title
