from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError
from collections import defaultdict
from odoo.tools.float_utils import float_is_zero


class StockLandedCost(models.Model):
    _inherit = 'stock.landed.cost'

    def _domain_department_id(self):
        branch_id = self.branch_id.id if self.branch_id else self.env.user.employee_id.branch_id.id
        return [('company_id', '=', self.env.company.id),
                ('parent_id', '=', branch_id),
                ('active', '=', True)
                ]

    company_id = fields.Many2one('res.company', string="Company",
                                 related='account_journal_id.company_id', default=lambda self: self.env.company)

    account_book_id = fields.Many2one("account.accounting.book", _("Accounting Book"),
                                      domain="[('active', '=', True)]",
                                      readonly=True, required=False,
                                      states={'draft': [('readonly', False)]})

    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                domain="[('company_id', '=', company_id), ('active', '=', True), ('department_level.value', 'in', ['company', 'subsidiary', 'branch'])]",
                                required=True,
                                readonly=True,
                                states={'draft': [('readonly', False)]})
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    domain=_domain_department_id, required=True,
                                    readonly=True,
                                    states={'draft': [('readonly', False)]})

    valuation_adjustment_select_moves = fields.One2many('stock.valuation.adjustment.select.move', 'cost_id',
                                                        string='Valuation adjustment select moves', copy=True,
                                                        states={'done': [('readonly', True)]})
    vendor_bill_id = fields.Many2one(
        'account.move', 'Vendor Bill', copy=False, domain=[('move_type', '=', 'in_invoice')], states={'done': [('readonly', True)]})

    @api.onchange('picking_ids')
    def _onchange_valuation_adjustment_moves(self):
        for cost in self:
            move_id_allocate_false = cost.valuation_adjustment_select_moves.filtered(
                lambda m: m.is_allocate is not True).move_id
            cost.valuation_adjustment_select_moves = [(5, 0, 0)]
            cost.valuation_adjustment_select_moves = cost._get_raws_valuation_adjustment(move_id_allocate_false)

    def _get_raws_valuation_adjustment(self, move_id_allocate_false):
        valuation_moves = []
        moves = self._get_targeted_move_ids()
        for move in moves:
            vals = self._get_raw_valuation_adjustment(self.id, move)
            if vals['move_id'] in move_id_allocate_false.ids:
                vals['is_allocate'] = False
            valuation_moves.append((0, 0, vals))
        return valuation_moves

    def _get_raw_valuation_adjustment(self, cost_id, move):
        data = {
            'company_id': move.company_id.id,
            'branch_id': move.branch_id.id,
            'department_id': move.department_id.id,
            'move_id': move.id.origin,
            'location_dest_id': move.location_dest_id.id,
            'product_id': move.product_id.id,
            'quantity': move.product_qty,
            'cost_id': cost_id,
            'currency_id': move.currency_id,
            'is_allocate': True
        }
        return data

    @api.onchange('branch_id')
    def _onchange_branch_id(self):
        for rec in self:
            if rec.branch_id:
                if rec.department_id.parent_id.id != rec.branch_id.id:
                    rec.department_id = False
                return {
                    'domain': {
                        'department_id': [('company_id', '=', rec.company_id.id),
                                          ('parent_id', '=', rec.branch_id.id),
                                          ('active', '=', True)],
                    }
                }

    @api.onchange('vendor_bill_id')
    def _onchange_vendor_bill_id(self):
        for cost in self:
            cost.cost_lines = False
            cost_lines = []
            for account_move_line in cost.vendor_bill_id.line_ids.filtered(lambda m: m.is_landed_costs_line is True):
                accounts_data = account_move_line.product_id.product_tmpl_id.get_product_accounts()
                vals = {
                    'product_id': account_move_line.product_id.id,
                    'name': account_move_line.product_id.name,
                    'split_method': account_move_line.product_id.product_tmpl_id.split_method_landed_cost or 'equal',
                    'price_unit': account_move_line.product_id.standard_price or 0.0,
                    'account_id': accounts_data['stock_input']
                }
                cost_lines.append((0, 0, vals))
            cost.cost_lines = cost_lines

    def _default_account_journal_id(self):
        """Take the journal configured in the company, else fallback on the stock journal."""
        lc_journal = self.env['account.journal']
        if self.env.company.lc_journal_id:
            lc_journal = self.env.company.lc_journal_id
        else:
            lc_journal = self.env['ir.property']._get("property_stock_journal", "product.category")

        if not lc_journal:
            error_msg = _(
                "No journal could be found in company"
            )
            raise UserError(error_msg)

        return lc_journal

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('vt.stock.landed.cost.sequence')
        return super().create(vals)

    @api.depends('company_id')
    def _compute_allowed_picking_ids(self):
        if self.company_id:
            self.env.cr.execute("""SELECT sm.picking_id, sm.company_id
                                         FROM stock_move AS sm
                                   INNER JOIN stock_valuation_layer AS svl ON svl.stock_move_id = sm.id
                                   INNER JOIN stock_picking AS sp ON sm.picking_id = sp.ID
                                   INNER JOIN stock_picking_type AS spt ON sp.picking_type_id = spt.ID
                                   INNER JOIN stock_picking_movement_type spmt ON spmt.ID = spt.movement_type_id
                                        WHERE sm.picking_id IS NOT NULL AND spt.code IN ('incoming', 'internal') AND spmt.value != 'P+' AND sm.company_id IN %s
                                     GROUP BY sm.picking_id, sm.company_id""", [tuple(self.company_id.ids)])
            valued_picking_ids_per_company = defaultdict(list)
            for res in self.env.cr.fetchall():
                valued_picking_ids_per_company[res[1]].append(res[0])
            for cost in self:
                cost.allowed_picking_ids = valued_picking_ids_per_company[cost.company_id.id]
        else:
            for cost in self:
                cost.allowed_picking_ids = False

    def compute_landed_cost(self):
        AdjustementLines = self.env['stock.valuation.adjustment.lines']
        AdjustementLines.search([('cost_id', 'in', self.ids)]).unlink()

        digits = self.env['decimal.precision'].precision_get('Product Price')
        towrite_dict = {}
        for cost in self.filtered(lambda cost: cost._get_targeted_move_ids()):
            total_qty = 0.0
            total_cost = 0.0
            total_weight = 0.0
            total_volume = 0.0
            total_line = 0.0
            all_val_line_values = cost.get_valuation_lines()
            for val_line_values in all_val_line_values:
                for cost_line in cost.cost_lines:
                    val_line_values.update({'cost_id': cost.id, 'cost_line_id': cost_line.id})
                    self.env['stock.valuation.adjustment.lines'].create(val_line_values)
                if cost.target_model == 'manufacturing' or val_line_values[
                    'move_id'] in cost.valuation_adjustment_select_moves.filtered(
                    lambda m: m.is_allocate is True).move_id.ids:
                    total_qty += val_line_values.get('quantity', 0.0)
                    total_weight += val_line_values.get('weight', 0.0)
                    total_volume += val_line_values.get('volume', 0.0)

                    former_cost = val_line_values.get('former_cost', 0.0)
                    # round this because former_cost on the valuation lines is also rounded
                    total_cost += tools.float_round(former_cost, precision_digits=digits) if digits else former_cost

                    total_line += 1

            for line in cost.cost_lines:
                value_split = 0.0
                for valuation in cost.valuation_adjustment_lines:
                    value = 0.0
                    if valuation.cost_line_id and valuation.cost_line_id.id == line.id:
                        if cost.target_model == 'manufacturing' or valuation.move_id.id in cost.valuation_adjustment_select_moves.filtered(
                                lambda m: m.is_allocate is True).move_id.ids:
                            if line.split_method == 'by_quantity' and total_qty:
                                per_unit = (line.price_unit / total_qty)
                                value = valuation.quantity * per_unit
                            elif line.split_method == 'by_weight' and total_weight:
                                per_unit = (line.price_unit / total_weight)
                                value = valuation.weight * per_unit
                            elif line.split_method == 'by_volume' and total_volume:
                                per_unit = (line.price_unit / total_volume)
                                value = valuation.volume * per_unit
                            elif line.split_method == 'equal':
                                value = (line.price_unit / total_line)
                            elif line.split_method == 'by_current_cost_price' and total_cost:
                                per_unit = (line.price_unit / total_cost)
                                value = valuation.former_cost * per_unit
                            else:
                                value = (line.price_unit / total_line)

                            if digits:
                                value = tools.float_round(value, precision_digits=digits, rounding_method='UP')
                                fnc = min if line.price_unit > 0 else max
                                value = fnc(value, line.price_unit - value_split)
                                value_split += value

                    if valuation.id not in towrite_dict:
                        towrite_dict[valuation.id] = value
                    else:
                        towrite_dict[valuation.id] += value
        for key, value in towrite_dict.items():
            AdjustementLines.browse(key).write({'additional_landed_cost': value})
        return True

    def button_validate(self):
        self._check_can_validate()
        cost_without_adjusment_lines = self.filtered(lambda c: not c.valuation_adjustment_lines)
        if cost_without_adjusment_lines:
            cost_without_adjusment_lines.compute_landed_cost()
        if not self._check_sum():
            raise UserError(_('Cost and adjustments lines do not match. You should maybe recompute the landed costs.'))

        for cost in self:
            cost = cost.with_company(cost.company_id)
            # config = self.env.company.res_config_id
            is_purchase_order_as_receipt = self.env.company.is_purchase_order_as_receipt
            if not is_purchase_order_as_receipt:
                # Phần sinh account_move, account_move_line
                move = self.env['account.move']
                move_vals = {
                    'journal_id': cost.account_journal_id.id,
                    'date': cost.date,
                    'ref': cost.name,
                    'line_ids': [],
                    'move_type': 'entry',
                }
                valuation_layer_ids = []
                cost_to_add_byproduct = defaultdict(lambda: 0.0)
                for line in cost.valuation_adjustment_lines.filtered(lambda line: line.move_id):
                    remaining_qty = sum(line.move_id.stock_valuation_layer_ids.mapped('remaining_qty'))
                    linked_layer = line.move_id.stock_valuation_layer_ids[:1]

                    # Prorate the value at what's still in stock
                    cost_to_add = (remaining_qty / line.move_id.product_qty) * line.additional_landed_cost
                    if not cost.company_id.currency_id.is_zero(cost_to_add):
                        valuation_layer = self.env['stock.valuation.layer'].create({
                            'value': cost_to_add,
                            'unit_cost': 0,
                            'quantity': 0,
                            'remaining_qty': 0,
                            'stock_valuation_layer_id': linked_layer.id,
                            'description': cost.name,
                            'stock_move_id': line.move_id.id,
                            'product_id': line.move_id.product_id.id,
                            'stock_landed_cost_id': cost.id,
                            'company_id': cost.company_id.id,
                            'branch_id': cost.branch_id.id,
                            'department_id': cost.department_id.id
                        })
                        linked_layer.remaining_value += cost_to_add
                        valuation_layer_ids.append(valuation_layer.id)
                    # Update the AVCO
                    product = line.move_id.product_id
                    if product.cost_method == 'average':
                        cost_to_add_byproduct[product] += cost_to_add
                    # `remaining_qty` is negative if the move is out and delivered proudcts that were not
                    # in stock.
                    qty_out = 0
                    if line.move_id._is_in():
                        qty_out = line.move_id.product_qty - remaining_qty
                    elif line.move_id._is_out():
                        qty_out = line.move_id.product_qty
                    move_vals['line_ids'] += line._create_accounting_entries(move, qty_out)

                # batch standard price computation avoid recompute quantity_svl at each iteration
                products = self.env['product.product'].browse(p.id for p in cost_to_add_byproduct.keys())
                for product in products:  # iterate on recordset to prefetch efficiently quantity_svl
                    if not float_is_zero(product.quantity_svl, precision_rounding=product.uom_id.rounding):
                        product.with_company(cost.company_id).sudo().with_context(
                            disable_auto_svl=True).standard_price += cost_to_add_byproduct[
                                                                         product] / product.quantity_svl

                move_vals['stock_valuation_layer_ids'] = [(6, None, valuation_layer_ids)]
                move = move.create(move_vals)
                cost.write({'state': 'done', 'account_move_id': move.id})
                move._post()
            else:
                cost.write({'state': 'done'})

            if cost.vendor_bill_id and cost.vendor_bill_id.state == 'posted' and cost.company_id.anglo_saxon_accounting:
                all_amls = cost.vendor_bill_id.line_ids | cost.account_move_id.line_ids
                for product in cost.cost_lines.product_id:
                    accounts = product.product_tmpl_id.get_product_accounts()
                    input_account = accounts['stock_input']
                    all_amls.filtered(
                        lambda aml: aml.account_id == input_account and not aml.full_reconcile_id).reconcile()

        return True


class StockLandedCostLine(models.Model):
    _inherit = 'stock.landed.cost.lines'

    account_book_id = fields.Many2one("account.accounting.book", _("Accounting Book"),
                                      domain="[('active', '=', True)]",
                                      readonly=True, required=False,
                                      related='cost_id.account_book_id',
                                      states={'draft': [('readonly', False)]}, store=True)

    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                related='cost_id.branch_id',
                                required=True, store=True)
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    related='cost_id.department_id',
                                    required=True, store=True)


class AdjustmentLines(models.Model):
    _inherit = 'stock.valuation.adjustment.lines'

    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                related='cost_id.branch_id',
                                required=True, store=True)
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    related='cost_id.department_id',
                                    required=True, store=True)
