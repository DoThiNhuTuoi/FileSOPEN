# -*- coding: utf-8 -*-

from odoo import models, fields


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'
    department_id = fields.Many2one(related='move_id.department_id', store=True)
    branch_id = fields.Many2one(related='move_id.branch_id', store=True)
    account_cost_type_id = fields.Many2one('account.cost.type', name='Cost type', store=True,
                                           related='move_id.stock_move_id.account_cost_type_id')
    account_cost_object_id = fields.Many2one('account.cost.object', name='Cost object', store=True,
                                             related='move_id.stock_move_id.account_cost_object_id')
    account_contract_id = fields.Many2one('account.contract', name='Contract', store=True,
                                          related='move_id.stock_move_id.account_contract_id')
    account_construction_id = fields.Many2one('account.construction', name='Construction', store=True,
                                              related='move_id.stock_move_id.account_construction_id')

    bank_account_id = fields.Many2one('res.partner.bank', string='Bank account')
    account_analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic account')
    account_project_id = fields.Many2one('project.project', string='Project')
    account_service_id = fields.Many2one('account.service', string='Services')
    picking_id = fields.Many2one('stock.picking', related='move_id.stock_move_id.picking_id')
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda s: s.env.company.currency_id)
    move_id = fields.Many2one('account.move', string='Journal Entry',
                              index=True, required=True, readonly=True, auto_join=True, ondelete="cascade",
                              check_company=True,
                              help="The move of this entry line.", default=lambda s: s.env.company)
