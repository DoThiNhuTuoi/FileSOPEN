from odoo import models, api, fields, _


class StockValuationAdjustmentSelectMove(models.Model):
    _name = "stock.valuation.adjustment.select.move"

    company_id = fields.Many2one(
        'res.company', 'Company',
        readonly=True, index=True, required=True,
        default=lambda self: self.env.company)
    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                related='move_id.branch_id', store=True)
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    related='move_id.department_id', store=True)
    location_dest_id = fields.Many2one('stock.location', string='Location', related='move_id.location_dest_id', store=True)
    product_id = fields.Many2one('product.product', string="Product", related='move_id.product_id', store=True)
    quantity = fields.Float("Quantity", related="move_id.product_qty" , store=True)
    is_allocate = fields.Boolean("Allocate", default=True)
    cost_id = fields.Many2one('stock.landed.cost', "Landed cost", ondelete='cascade')
    cost_price_unit = fields.Monetary("Cost price", related="move_id.cost_price_unit", readonly=True, store=True)
    cost_amount_total = fields.Monetary("Amount total", related="move_id.cost_amount_total", readonly=True, store=True)
    currency_id = fields.Many2one('res.currency', 'Currency', related='move_id.currency_id', readonly=True, store=True)
    move_name = fields.Char('Stock move name', related='move_id.picking_id.name', readonly="1", store=True)
    move_id = fields.Many2one(
        'stock.move', 'Stock Move',
        check_company=True,
        help="Change to a better name", index=True)
