# -*- coding: utf-8 -*-

from odoo import fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    is_delivery_more_than_available = fields.Boolean(string='Delivery more than available')
    is_purchase_order_as_receipt = fields.Boolean(string='Purchase Order As Receipt')
