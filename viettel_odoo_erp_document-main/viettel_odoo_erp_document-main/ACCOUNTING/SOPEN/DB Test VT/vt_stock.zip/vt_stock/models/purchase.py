# -*- coding: utf-8 -*-

from odoo import _, models, fields, api


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    is_transfer_completed = fields.Boolean(compute='_is_transfer_completed', store=True)

    @api.depends('order_line.remain_quantity')
    def _is_transfer_completed(self):
        for line in self:
            if_completed = True
            for order_line in line.order_line:
                if order_line.remain_quantity > 0:
                    if_completed = False
            line.is_transfer_completed = if_completed

    def name_get(self):
        result = []
        for po in self:
            name = po.name + ' - ' + str(po.date_order.date())
            result.append((po.id, name))
        return result


class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    remain_quantity = fields.Float(compute='get_remain_quantity', string='Remain quantity', store=True)
    remain_value = fields.Monetary(compute='get_remain_value')
    order_id_ref = fields.Char(string='Order Reference', copy=False, related='order_id.partner_ref',
                               store=False)

    @api.depends('remain_quantity', 'price_unit')
    def get_remain_value(self):
        for line in self:
            line.remain_value = line.remain_quantity * line.price_unit

    @api.onchange('product_uom_qty', 'qty_received')
    def get_remain_quantity(self):
        for line in self:
            line.remain_quantity = line.product_uom_qty - line.qty_received

    @api.depends('move_ids.state', 'move_ids.product_uom_qty', 'move_ids.product_uom')
    def _compute_qty_received(self):
        super(PurchaseOrderLine, self)._compute_qty_received()
        for line in self:
            if line.qty_received_method == 'stock_moves':
                line.remain_quantity = line.product_uom_qty - line.qty_received
