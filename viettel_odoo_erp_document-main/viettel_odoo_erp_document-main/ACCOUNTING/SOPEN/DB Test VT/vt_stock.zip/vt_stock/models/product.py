# -*- coding: utf-8 -*-


from odoo import models, fields, api
from odoo.tools import float_is_zero

class Product(models.Model):
    _inherit = 'product.product'

    # apply condition search for branch_id and location_id
    def apply_extend_domain(self, domain, branch_id=False, location_id=False):
        branch = location = None
        if branch_id and location_id:
            branch = branch_id
            location = location_id
        elif hasattr(self.env, 'branch_id') and hasattr(self.env, 'location_id') and \
                self.env.location_id and self.env.branch_id:
            branch = self.env.branch_id.id
            location = self.env.location_id.id
        if domain and branch and location:
            domain.append(('branch_id', '=', branch))
            domain_stock_move = [
                '|', ('stock_move_id.location_dest_id', '=', location),
                ('stock_move_id.location_id', '=', location)
            ]
            domain.extend(domain_stock_move)

    def apply_extend_domain_for_fifo_vacum(self, domain, branch_id=False, location_id=False):
        branch = location = None
        if branch_id and location_id:
            branch = branch_id
            location = location_id
        elif hasattr(self.env, 'branch_id') and hasattr(self.env, 'location_id') and \
                self.env.location_id and self.env.branch_id:
            branch = self.env.branch_id.id
            location = self.env.location_id.id
        if domain and branch and location:
            domain.append(('branch_id', '=', branch))
            domain.append(('stock_move_id.location_dest_id', '=', location))

    @api.depends('stock_valuation_layer_ids')
    @api.depends_context('to_date', 'company')
    def _compute_value_svl(self, branch_id=False, location=False):
        # OVERRIDE
        """Compute `value_svl` and `quantity_svl`."""
        company_id = self.env.company.id
        domain = [
            ('product_id', 'in', self.ids),
            ('company_id', '=', company_id)
        ]
        # apply domain compute by branch_id and location_id
        if branch_id and location and hasattr(location, 'id') and hasattr(branch_id, 'id'):
            self.apply_extend_domain(domain, branch_id.id, location.id)

        if self.env.context.get('to_date'):
            to_date = fields.Datetime.to_datetime(self.env.context['to_date'])
            domain.append(('create_date', '<=', to_date))
        groups = self.env['stock.valuation.layer'].read_group(domain, ['value:sum', 'quantity:sum'], ['product_id'])
        products = self.browse()
        for group in groups:
            product = self.browse(group['product_id'][0])
            product.value_svl = self.env.company.currency_id.round(group['value'])
            product.quantity_svl = group['quantity']
            products |= product
        remaining = (self - products)
        remaining.value_svl = 0
        remaining.quantity_svl = 0

    #OVERRIDE
    def _prepare_in_svl_vals(self, quantity, unit_cost):
        """Prepare the values for a stock valuation layer created by a receipt.

        :param quantity: the quantity to value, expressed in `self.uom_id`
        :param unit_cost: the unit cost to value `quantity`
        :return: values to use in a call to create
        :rtype: dict
        """
        self.ensure_one()
        vals = {
            'product_id': self.id,
            'value': unit_cost * quantity,
            'unit_cost': unit_cost,
            'quantity': quantity,
        }
        # add cost method
        if self.cost_method in ('average', 'fifo', 'specific'):
            vals['remaining_qty'] = quantity
            vals['remaining_value'] = vals['value']
        return vals

    def _prepare_out_svl_vals(self, quantity, company, branch_id=False, location_id=False, arr_lot_value_quantity=False):
        # OVERRIDE
        """Prepare the values for a stock valuation layer created by a delivery.

        :param quantity: the quantity to value, expressed in `self.uom_id`
        :return: values to use in a call to create
        :rtype: dict
        """
        # add condition to env
        self.ensure_one()
        self._compute_value_svl(branch_id, location_id)
        # Quantity is negative for out valuation layers.
        quantity = -1 * quantity
        vals = {
            'product_id': self.id,
            'value': quantity * self.standard_price,
            'unit_cost': self.standard_price,
            'quantity': quantity
        }
        # add specific cost type method
        if self.cost_method in ('average', 'fifo', 'specific'):
            if self.cost_method == 'specific':
                spec_vals = self._run_spec(company, branch_id, location_id, arr_lot_value_quantity)
                vals['remaining_qty'] = spec_vals.get('remaining_qty')
            else:
                fifo_vals = self._run_fifo(abs(quantity), company, branch_id, location_id)
                vals['remaining_qty'] = fifo_vals.get('remaining_qty')
            # in case of AVCO, fix rounding issue of standard price when needed.
            if self.cost_method == 'average':
                rounding_error = self.standard_price * self.quantity_svl - self.value_svl
                vals['value'] += self.env.company.currency_id.round(rounding_error)
                if self.quantity_svl:
                    vals['unit_cost'] = self.value_svl / self.quantity_svl
                    vals['value'] = quantity * self.value_svl / self.quantity_svl
            if self.cost_method == 'fifo':
                vals.update(fifo_vals)
            if self.cost_method == 'specific':
                vals.update(spec_vals)
        return vals

    def _run_fifo(self, quantity, company, branch_id=False, location_id=False):
        # OVERRIDE
        self.ensure_one()
        # Find back incoming stock valuation layers (called candidates here) to value `quantity`.
        qty_to_take_on_candidates = quantity
        domain = [
            ('product_id', '=', self.id),
            ('remaining_qty', '>', 0),
            ('company_id', '=', company.id),
        ]
        # add condition branch and location
        if branch_id and location_id:
            self.apply_extend_domain(domain)
        candidates = self.env['stock.valuation.layer'].sudo().search(domain, order='accounting_date asc')
        new_standard_price = 0
        tmp_value = 0  # to accumulate the value taken on the candidates
        for candidate in candidates:
            qty_taken_on_candidate = min(qty_to_take_on_candidates, candidate.remaining_qty)

            candidate_unit_cost = candidate.remaining_value / candidate.remaining_qty
            new_standard_price = candidate_unit_cost
            value_taken_on_candidate = qty_taken_on_candidate * candidate_unit_cost
            value_taken_on_candidate = candidate.currency_id.round(value_taken_on_candidate)
            new_remaining_value = candidate.remaining_value - value_taken_on_candidate

            candidate_vals = {
                'remaining_qty': candidate.remaining_qty - qty_taken_on_candidate,
                'remaining_value': new_remaining_value,
            }

            candidate.write(candidate_vals)

            qty_to_take_on_candidates -= qty_taken_on_candidate
            tmp_value += value_taken_on_candidate

            if float_is_zero(qty_to_take_on_candidates, precision_rounding=self.uom_id.rounding):
                if float_is_zero(candidate.remaining_qty, precision_rounding=self.uom_id.rounding):
                    next_candidates = candidates.filtered(lambda svl: svl.remaining_qty > 0)
                    new_standard_price = next_candidates and next_candidates[0].unit_cost or new_standard_price
                break

        # Update the standard price with the price of the last used candidate, if any.
        if new_standard_price and self.cost_method == 'fifo':
            self.sudo().with_company(company.id).with_context(disable_auto_svl=True).standard_price = new_standard_price

        # If there's still quantity to value but we're out of candidates, we fall in the
        # negative stock use case. We chose to value the out move at the price of the
        # last out and a correction entry will be made once `_fifo_vacuum` is called.
        vals = {}
        if float_is_zero(qty_to_take_on_candidates, precision_rounding=self.uom_id.rounding):
            vals = {
                'value': -tmp_value,
                'unit_cost': tmp_value / quantity,
            }
        else:
            assert qty_to_take_on_candidates > 0
            last_fifo_price = new_standard_price or self.standard_price
            negative_stock_value = last_fifo_price * -qty_to_take_on_candidates
            tmp_value += abs(negative_stock_value)
            vals = {
                'remaining_qty': -qty_to_take_on_candidates,
                'value': -tmp_value,
                'unit_cost': last_fifo_price,
            }
        return vals

    def _run_fifo_vacuum(self, company=None, branch_id=False, location_id=False, department_id=False):
        # OVERRIDE
        """Compensate layer valued at an estimated price with the price of future receipts
        if any. If the estimated price is equals to the real price, no layer is created but
        the original layer is marked as compensated.

        :param company: recordset of `res.company` to limit the execution of the vacuum
        """
        self.ensure_one()
        if company is None:
            company = self.env.company
        domain = [
            ('product_id', '=', self.id),
            ('remaining_qty', '<', 0),
            ('stock_move_id', '!=', False),
            ('company_id', '=', company.id),
        ]
        # Apply condition branch Id and location if null dont calculate value
        if branch_id and location_id:
            self.apply_extend_domain_for_fifo_vacum(domain, branch_id.id, location_id.id)
        svls_to_vacuum = self.env['stock.valuation.layer'].sudo().search(domain, order='create_date, id')
        for svl_to_vacuum in svls_to_vacuum:
            domain = [
                ('company_id', '=', svl_to_vacuum.company_id.id),
                ('product_id', '=', self.id),
                ('remaining_qty', '>', 0),
                '|',
                    ('create_date', '>', svl_to_vacuum.create_date),
                    '&',
                        ('create_date', '=', svl_to_vacuum.create_date),
                        ('id', '>', svl_to_vacuum.id)
            ]
            # Apply condition branch Id and location
            if branch_id and location_id:
                self.apply_extend_domain_for_fifo_vacum(domain, branch_id.id, location_id.id)
            candidates = self.env['stock.valuation.layer'].sudo().search(domain)
            if not candidates:
                break
            qty_to_take_on_candidates = abs(svl_to_vacuum.remaining_qty)
            qty_taken_on_candidates = 0
            tmp_value = 0
            for candidate in candidates:
                qty_taken_on_candidate = min(candidate.remaining_qty, qty_to_take_on_candidates)
                qty_taken_on_candidates += qty_taken_on_candidate

                candidate_unit_cost = candidate.remaining_value / candidate.remaining_qty
                value_taken_on_candidate = qty_taken_on_candidate * candidate_unit_cost
                value_taken_on_candidate = candidate.currency_id.round(value_taken_on_candidate)
                new_remaining_value = candidate.remaining_value - value_taken_on_candidate

                candidate_vals = {
                    'remaining_qty': candidate.remaining_qty - qty_taken_on_candidate,
                    'remaining_value': new_remaining_value
                }
                candidate.write(candidate_vals)

                qty_to_take_on_candidates -= qty_taken_on_candidate
                tmp_value += value_taken_on_candidate
                if float_is_zero(qty_to_take_on_candidates, precision_rounding=self.uom_id.rounding):
                    break

            # Get the estimated value we will correct.
            remaining_value_before_vacuum = svl_to_vacuum.unit_cost * qty_taken_on_candidates
            new_remaining_qty = svl_to_vacuum.remaining_qty + qty_taken_on_candidates
            corrected_value = remaining_value_before_vacuum - tmp_value
            svl_to_vacuum.write({
                'remaining_qty': new_remaining_qty,
            })

            # Don't create a layer or an accounting entry if the corrected value is zero.
            if svl_to_vacuum.currency_id.is_zero(corrected_value):
                continue

            corrected_value = svl_to_vacuum.currency_id.round(corrected_value)
            move = svl_to_vacuum.stock_move_id
            vals = {
                'product_id': self.id,
                'value': corrected_value,
                'unit_cost': 0,
                'quantity': 0,
                'remaining_qty': 0,
                'stock_move_id': move.id,
                'company_id': move.company_id.id,
                'description': 'Revaluation of %s (negative inventory)' % move.picking_id.name or move.name,
                'stock_valuation_layer_id': svl_to_vacuum.id,
            }
            # Apply condition branch Id and department if null dont calculate value
            if branch_id:
                vals.update({'branch_id': branch_id.id})
            if department_id:
                vals.update({'department_id': department_id.id})
            vacuum_svl = self.env['stock.valuation.layer'].sudo().create(vals)

            # If some negative stock were fixed, we need to recompute the standard price.
            product = self.with_company(company.id)
            if product.cost_method == 'average' and not float_is_zero(product.quantity_svl, precision_rounding=self.uom_id.rounding):
                product.sudo().with_context(disable_auto_svl=True).write({'standard_price': product.value_svl / product.quantity_svl})

            # Create the account move.
            if self.valuation != 'real_time':
                continue
            vacuum_svl.stock_move_id._account_entry_move(
                vacuum_svl.quantity, vacuum_svl.description, vacuum_svl.id, vacuum_svl.value
            )
            # Create the related expense entry
            self._create_fifo_vacuum_anglo_saxon_expense_entry(vacuum_svl, svl_to_vacuum)

    def _run_spec(self, company, branch_id=False, location_id=False, arr_lot_value_quantity=False):
        # OVERRIDE
        self.ensure_one()
        arr_vals = []
        # Find back incoming stock valuation layers (called candidates here) to value `quantity`.
        for lot_id in arr_lot_value_quantity.keys():
            quantity = arr_lot_value_quantity.get(lot_id)
            qty_to_take_on_candidates = quantity
            # domain = [
            #     ('product_id', '=', self.id),
            #     ('remaining_qty', '>', 0),
            #     ('company_id', '=', company.id)
            # ]
            # # add condition branch and location
            # if branch_id and location_id:
            #     self.apply_extend_domain(domain)
            # candidates = self.env['stock.valuation.layer'].sudo().search(domain)
            domain = [
                ('product_id', '=', self.id),
                ('company_id', '=', company.id),
                ('branch_id', '=', branch_id.id),
                ('lot_id', '=', lot_id),
                ('stock_valuation_layer_ids.remaining_qty', '>', '0')
            ]
            move_line_q = self.env['stock.move.line'].sudo().search(domain, order='date asc')
            move_lines = move_line_q.filtered(lambda move_line: move_line.is_remain_qty_spec == True)
            new_standard_price = 0
            tmp_value = 0  # to accumulate the value taken on the candidates
            for move_line in move_lines:
                candidate = move_line.stock_valuation_layer_ids
                remain_qty = move_line.qty_done - move_line.qty_spec_out
                candidate_unit_cost = candidate.remaining_value / candidate.remaining_qty
                qty_taken_on_candidate = min(qty_to_take_on_candidates, remain_qty)
                new_standard_price = candidate_unit_cost
                value_taken_on_candidate = qty_taken_on_candidate * candidate_unit_cost
                value_taken_on_candidate = candidate.currency_id.round(value_taken_on_candidate)
                new_remaining_value = candidate.remaining_value - value_taken_on_candidate

                candidate_vals = {
                    'remaining_qty': candidate.remaining_qty - qty_taken_on_candidate,
                    'remaining_value': new_remaining_value,
                }
                candidate.write(candidate_vals)
                move_line_vals = {
                    'qty_spec_out': move_line.qty_spec_out + qty_taken_on_candidate
                }
                move_line.write(move_line_vals)
                qty_to_take_on_candidates -= qty_taken_on_candidate
                tmp_value += value_taken_on_candidate
                if float_is_zero(qty_to_take_on_candidates, precision_rounding=self.uom_id.rounding):
                    if float_is_zero(candidate.remaining_qty, precision_rounding=self.uom_id.rounding):
                        next_candidates = move_lines.filtered(
                            lambda move_line: move_line.stock_valuation_layer_ids.remaining_qty > 0)
                        new_standard_price = next_candidates and next_candidates[0].unit_cost or new_standard_price
                    break

            # Update the standard price with the price of the last used candidate, if any.
            if new_standard_price and self.cost_method == 'fifo':
                self.sudo().with_company(company.id).with_context(disable_auto_svl=True).standard_price = new_standard_price

            # If there's still quantity to value but we're out of candidates, we fall in the
            # negative stock use case. We chose to value the out move at the price of the
            # last out and a correction entry will be made once `_fifo_vacuum` is called.
            vals = {}
            if float_is_zero(qty_to_take_on_candidates, precision_rounding=self.uom_id.rounding):
                vals = {
                    'value': -tmp_value,
                    'quantity': quantity,
                }
                arr_vals.append(vals)
            else:
                assert qty_to_take_on_candidates > 0
                last_fifo_price = new_standard_price or self.standard_price
                negative_stock_value = last_fifo_price * -qty_to_take_on_candidates
                tmp_value += abs(negative_stock_value)
                vals = {
                    'remaining_qty': -qty_to_take_on_candidates,
                    'value': -tmp_value,
                    'unit_cost': last_fifo_price,
                }
        total_value = total_quantity = 0
        for i_vals in arr_vals:
            total_value -= i_vals.get('value')
            total_quantity += i_vals.get('quantity')
        return_vals = {
            'value': total_value,
            'unit_cost': total_value / total_quantity,
        }
        return return_vals
