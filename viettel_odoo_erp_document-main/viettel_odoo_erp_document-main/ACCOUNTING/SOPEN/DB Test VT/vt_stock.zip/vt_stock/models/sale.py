# -*- coding: utf-8 -*-

from odoo import _, models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    is_transfer_completed = fields.Boolean(compute='_is_transfer_completed', store=True)

    @api.depends('order_line.remain_quantity')
    def _is_transfer_completed(self):
        for line in self:
            if_completed = True
            for order_line in line.order_line:
                if order_line.remain_quantity > 0:
                    if_completed = False
            line.is_transfer_completed = if_completed


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    remain_quantity = fields.Float(compute='get_remain_quantity', string='Remain quantity', store=True)
    remain_value = fields.Monetary(compute='get_remain_value')
    order_id_ref = fields.Char(string='Order Reference', copy=False, related='order_id.client_order_ref', store=False)

    @api.depends('remain_quantity', 'price_unit')
    def get_remain_value(self):
        for line in self:
            line.remain_value = line.remain_quantity * line.price_unit

    date_order = fields.Datetime(related='order_id.date_order', string='Order Date', readonly=True)

    @api.onchange('product_uom_qty', 'qty_delivered')
    def get_remain_quantity(self):
        for line in self:
            line.remain_quantity = line.product_uom_qty - line.qty_delivered

    @api.depends('move_ids.state', 'move_ids.scrapped', 'move_ids.product_uom_qty', 'move_ids.product_uom')
    def _compute_qty_delivered(self):
        super(SaleOrderLine, self)._compute_qty_delivered()
        for line in self:
            line = self.env['sale.order.line'].browse(line.id)
            line.update({'remain_quantity': line.product_uom_qty - line.qty_delivered})
            line.remain_quantity = line.product_uom_qty - line.qty_delivered
