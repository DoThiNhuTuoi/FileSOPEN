# -*- coding: utf-8 -*-


from odoo import models, fields, api
from datetime import timedelta

class AccountMove(models.Model):
    _inherit = 'account.move'
    # branch_id = fields.Many2one('hr.department', name='Branch', compute='_compute_origin_from_stock_move_id', store=True)
    # department_id = fields.Many2one('hr.department', name='Department', compute='_compute_origin_from_stock_move_id', store=True)
    date_trx = fields.Datetime(name='Transaction Date', related='stock_move_id.picking_id.date_trx', store=True)
    date = fields.Date(compute='_get_date', default=fields.Datetime.now, store=True)
    picking_id = fields.Many2one('stock.picking', related='stock_move_id.picking_id')

    def _get_date(self):
        for record in self:
            record.date = record.stock_move_id.date.date()

    @api.model
    def create(self, vals):
        if vals and 'stock_move_id' in vals:
            stock_move = self.env['stock.move'].browse(vals.get('stock_move_id'))
            if stock_move:
                if stock_move.branch_id:
                    vals.update({'branch_id': stock_move.branch_id.id})
                if stock_move.department_id:
                    vals.update({'department_id': stock_move.department_id.id})
                if stock_move.picking_id and stock_move.picking_id.date:
                    date = stock_move.picking_id.date
                    vals.update({'date': date.date()})
        return super(AccountMove, self).create(vals)

    # @api.depends('stock_move_id')
    # def _compute_origin_from_stock_move_id(self):
    #     for move in self:
    #         if move.stock_move_id:
    #             if move.stock_move_id.branch_id:
    #                 move.branch_id = move.stock_move_id.branch_id
    #             if move.stock_move_id.department_id:
    #                 move.department_id = move.stock_move_id.department_id


