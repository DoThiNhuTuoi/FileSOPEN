# -*- coding: utf-8 -*-
import json

from odoo import models, fields, api
from odoo.tools import float_is_zero


class StockMove(models.Model):
    _inherit = 'stock.move'
    movement_code = fields.Selection('Operation Code for Returns', related='picking_id.picking_type_id.code',
                                     store=False)
    movement_type = fields.Char('Operation Type for Returns', related='picking_id.movement_type_value',
                                      store=True)
    in_out_type = fields.Selection([('in', 'In'), ('out', 'Out'), ('internal', 'Internal')])
    account_book_id = fields.Many2one('account.accounting.book', string='Accounting Book', store=True)
    branch_id = fields.Many2one('hr.department', name='Branch', store=True)
    department_id = fields.Many2one('hr.department', name='Department', store=True)
    account_cost_object_id = fields.Many2one('account.cost.object', name='Cost object')
    account_cost_type_id = fields.Many2one('account.cost.type', name='Cost type')
    account_contract_id = fields.Many2one('account.contract', name='Contract', store=True)
    currency_id = fields.Many2one('res.currency', 'Currency', related='company_id.currency_id', readonly=True,
                                  required=True)
    sale_id = fields.Many2one('sale.order', name='Sale order', copy=False)
    purchase_id = fields.Many2one('purchase.order', name='Purchase order', copy=False)
    sell_price_unit = fields.Float('Sell price unit', digits=0)
    amount_sell = fields.Float('Amount', digits=0)
    # Thành tiền
    cost_price_unit = fields.Monetary('Cost price unit', related='stock_valuation_layer_ids.unit_cost', digits=0)
    cost_amount_total = fields.Monetary('Value', related='stock_valuation_layer_ids.value', digits=0)
    # mrp_production_id = fields.Many2one('mrp.production', name='Mrp Production')
    account_construction_id = fields.Many2one('account.construction', name='Construction')
    picking_accounting_date = fields.Datetime(related='picking_id.date')

    purchase_line_id = fields.Many2one('purchase.order.line', 'Purchase Line', index=True, copy=False)
    sale_line_id = fields.Many2one('sale.order.line', 'Sale Line', index=True, copy=False)
    valuation_adjustment_lines = fields.One2many('stock.valuation.adjustment.lines', 'move_id')
    origin = fields.Char("Source Document", copy=False)
    # Số lô
    # HSD
    # Mã thống kê

    order_id_domain = fields.Char(related='picking_id.order_id_domain', store=False)
    allow_stock_location_ids = fields.Many2many('stock.location', related='picking_id.allow_stock_location_ids')
    allow_purchase_ids = fields.Many2many('purchase.order', compute='_compute_allow_purchase_ids')

    @api.depends('partner_id', 'picking_id.partner_id')
    def _compute_allow_purchase_ids(self):
        for move in self:
            partner_id = None
            if move.picking_id and move.picking_id.partner_id:
                partner_id = move.picking_id.partner_id.ids
            else:
                partner_id = move.partner_id.ids
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'purchase'),
                      # ('branch_id', '=', branch_id),
                      ('partner_id', 'in', partner_id)]
            move.allow_purchase_ids = self.env['purchase.order'].search(domain)

    allow_sale_ids = fields.Many2many('sale.order', compute='_compute_allow_sale_ids')

    @api.depends('partner_id', 'picking_id.partner_id')
    def _compute_allow_sale_ids(self):
        for move in self:
            partner_id = None
            if move.picking_id and move.picking_id.partner_id:
                partner_id = move.picking_id.partner_id.ids
            else:
                partner_id = move.partner_id.ids
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'sale'),
                      # ('branch_id', '=', branch_id),
                      ('partner_id', 'in', partner_id)]
            move.allow_sale_ids = self.env['sale.order'].search(domain)

    date = fields.Datetime(
        'Date Scheduled', index=True,
        help="Scheduled date until move is done, then date of actual move processing")

    def name_get(self):
        result = []
        for po in self:
            name = po.product_id.name
            result.append((po.id, name))
        return result

    def _prepare_common_svl_vals(self):
        res = super(StockMove, self)._prepare_common_svl_vals()
        if self.picking_type_id.code != 'internal':
            res.update({'branch_id': self.branch_id.id,
                        'department_id': self.department_id.id})
        return res

    def _create_out_svl(self, forced_quantity=None):
        # OVERRIDE
        """Create a `stock.valuation.layer` from `self`.

        :param forced_quantity: under some circunstances, the quantity to value is different than
            the initial demand of the move (Default value = None)
        """
        svl_vals_list = []
        for move in self:
            arr_lot_value_quantity = {}
            move = move.with_company(move.company_id)
            valued_move_lines = move._get_out_move_lines()
            valued_quantity = 0
            for valued_move_line in valued_move_lines:
                temp_quantity = valued_move_line.product_uom_id._compute_quantity(valued_move_line.qty_done,
                                                                                     move.product_id.uom_id)
                valued_quantity += temp_quantity
                if move.product_id.cost_method == 'specific':
                    arr_lot_value_quantity.update({valued_move_line.lot_id.id: temp_quantity})
            if float_is_zero(forced_quantity or valued_quantity, precision_rounding=move.product_id.uom_id.rounding):
                continue
            # Apply condition branch and location
            svl_vals = move.product_id._prepare_out_svl_vals(forced_quantity or valued_quantity, move.company_id,
                                                             move.branch_id, move.location_id, arr_lot_value_quantity)
            svl_vals.update(move._prepare_common_svl_vals())
            if forced_quantity:
                svl_vals['description'] = 'Correction of %s (modification of past move)' % move.picking_id.name \
                                          or move.name
            svl_vals_list.append(svl_vals)
        return self.env['stock.valuation.layer'].sudo().create(svl_vals_list)

    def _account_entry_move(self, qty, description, svl_id, cost):
        if not (self.picking_id.picking_type_id.movement_type_id.value == 'A+' and
                self.env.company.is_purchase_order_as_receipt):
            super(StockMove, self)._account_entry_move(qty, description, svl_id, cost)

    def _prepare_account_move_line(self, qty, cost, credit_account_id, debit_account_id, description):
        # find account in stock_picking_type first
        debit_account = credit_account = None
        if hasattr(self.picking_type_id, 'account_debit_id') \
                and self.picking_type_id.account_debit_id:
            debit_account = self.picking_type_id.account_debit_id
        if hasattr(self.picking_type_id, 'account_credit_id') \
                and self.picking_type_id.account_credit_id:
            credit_account = self.picking_type_id.account_credit_id
        if debit_account and credit_account:
            credit_account_id = credit_account.id
            debit_account_id = debit_account.id
        return super(StockMove, self)._prepare_account_move_line(qty, cost, credit_account_id, debit_account_id, description)

    def _action_done(self, cancel_backorder=False):
        # OVERRIDE
        # Init a dict that will group the moves by valuation type, according to `move._is_valued_type`.
        valued_moves = {valued_type: self.env['stock.move'] for valued_type in self._get_valued_types()}
        for move in self:
            if float_is_zero(move.quantity_done, precision_rounding=move.product_uom.rounding):
                continue
            for valued_type in self._get_valued_types():
                if getattr(move, '_is_%s' % valued_type)():
                    valued_moves[valued_type] |= move

        res = super(StockMove, self)._action_done(cancel_backorder=cancel_backorder)

        # For every in move, run the vacuum for the linked product.
        products_to_vacuum = valued_moves['in'].mapped('product_id')
        company = valued_moves['in'].mapped('company_id') and valued_moves['in'].mapped('company_id')[0] or self.env.company
        for product_to_vacuum in products_to_vacuum:
            # Apply condition branch and location
            product_to_vacuum._run_fifo_vacuum(company, self.branch_id, self.location_dest_id, self.department_id)
        return res

    @api.onchange('product_id')
    def onchange_product_id(self):
        super(StockMove, self).onchange_product_id()
        if not self.branch_id:
            self.branch_id = self.picking_id.branch_id.id
        if not self.account_book_id:
            self.account_book_id = self.picking_id.account_book_id.id
        if not self.department_id:
            self.department_id = self.picking_id.department_id.id
        if not self.account_contract_id:
            self.account_contract_id = self.picking_id.account_contract_id.id
        self.sell_price_unit = self.product_id.list_price
        self.amount_sell = self.sell_price_unit * self.product_qty

    @api.onchange('purchase_id')
    def onchange_purchase_id(self):
        self.purchase_line_id = None

    @api.onchange('sale_id')
    def onchange_sale_id(self):
        self.sale_line_id = None

    @api.onchange('sell_price_unit', 'product_qty')
    def onchange_price_and_quantity(self):
        self.amount_sell = self.sell_price_unit * self.product_qty
