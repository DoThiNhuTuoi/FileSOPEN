# -*- coding: utf-8 -*-

import logging

from odoo import _, models, api, fields

_logger = logging.getLogger(__name__)

class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    parent_id = fields.Many2one('stock.picking.type', "Parent picking type", domain=[('code', 'in', ['internal', 'mrp_operation'])],
                                store=True, required=False)

    @api.model
    def create(self, vals):
        res = super(StockPickingType, self).create(vals)
        if res:
            if res.code == 'internal':
                vals_in = dict(vals)
                vals_out = dict(vals)
                move_value = self.env['stock.picking.movement.type'].browse(vals.get('movement_type_id'))
                account_id = move_type_in_id = move_type_out_id = None
                if move_value:
                    move_type = self.env['stock.picking.movement.type'].search([('value', 'in', [move_value.value+'+', move_value.value+'-'])])
                    move_type_in = move_type.filtered(lambda x: '+' in x.value)
                    if move_type_in:
                        move_type_in_id = move_type_in[0].id
                    move_type_out = move_type.filtered(lambda x: '-' in x.value)
                    if move_type_out:
                        move_type_out_id = move_type_out[0].id
                supplier_wh = self.env.ref('stock.stock_location_suppliers').id
                customer_wh = self.env.ref('stock.stock_location_customers').id
                account = self.env['account.account'].search([('code', 'like', '151%')], limit=1)
                if account:
                    account_id = account.id
                vals_in.update({'name': _('Incoming ') + vals.get('name'),
                                'default_location_src_id': supplier_wh,
                                'code': 'incoming',
                                'movement_type_id': move_type_in_id,
                                'account_debit_id': account_id,
                                'is_revaluation_cost': False,
                                'return_picking_type_id': False,
                                'parent_id': res.id
                                })

                vals_out.update({'name': _('Outgoing ') + vals.get('name'),
                                 'default_location_dest_id': customer_wh,
                                 'code': 'outgoing',
                                 'movement_type_id': move_type_out_id,
                                 'account_credit_id': account_id,
                                 'is_revaluation_cost': False,
                                 'return_picking_type_id': False,
                                 'parent_id': res.id
                                 })
                res_in = super(StockPickingType, self).create(vals_in)
                res_out = super(StockPickingType, self).create(vals_out)
        return res