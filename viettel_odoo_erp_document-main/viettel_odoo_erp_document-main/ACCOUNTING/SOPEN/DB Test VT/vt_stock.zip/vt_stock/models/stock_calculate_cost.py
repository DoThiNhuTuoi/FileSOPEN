# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from dateutil.relativedelta import relativedelta
import math
from odoo.exceptions import ValidationError

from datetime import datetime, timedelta, time
import calendar


class StockCalculatePeriod(models.Model):
    _name = 'stock.calculate.period'

    name = fields.Char('Name')
    value = fields.Char('Value')


class StockCalculateCost(models.Model):
    _name = 'stock.calculate.cost'
    _description = 'Stock Calculate Cost'

    company_id = fields.Many2one(
        'res.company', 'Company', required=True,
        default=lambda s: s.env.company.id, index=True)

    def _domain_branch_id(self):
        return [('company_id', '=', self.env.company.id),
                ('active', '=', True),
                ('id', 'in', self.env.user.employee_id.branch_id.ids),
                ('department_level.value', 'in',
                 ['company', 'subsidiary', 'branch'])]

    @api.onchange('branch_id')
    def _onchange_branch_id(self):
        for rec in self:
            if rec.branch_id:
                if rec.department_id.parent_id.id != rec.branch_id.id:
                    rec.department_id = False
                return {
                    'domain': {
                        'department_id': [('company_id', '=', rec.company_id.id),
                                          ('parent_id', '=', rec.branch_id.id),
                                          ('active', '=', True),
                                          ('department_level.value', 'in',
                                           ['department', 'office', 'center', 'team', 'factory'])
                                          ],
                    }
                }

    branch_id = fields.Many2one('hr.department', string='Branch', domain=_domain_branch_id, required=True,
                                default=lambda s: s.env.user.employee_id.branch_id,
                                help='Leave this field empty if this record is shared between branches')

    def _domain_branch_ids(self):
        return [('id', 'in', self.env.user.access_branch_rel_ids.branch_id.ids)]

    branch_ids = fields.Many2many('hr.department', domain=_domain_branch_ids, required=True)

    department_id = fields.Many2one('hr.department', name='Department', default=lambda s: s.env.user.department_id)

    target_mode = fields.Selection([('all', 'All'), ('selected_items', 'Selected item')], default='all')
    period = fields.Many2one('stock.calculate.period', 'Period', required=True)
    period_value = fields.Char(related='period.value', store=False)
    date_from = fields.Date('Date from', required=True)
    date_to = fields.Date('Date to', required=True)
    cost_stock = fields.Selection([('by_location', 'Calculation by location'),
                                   ('not_by_location', 'Calculation not by location')])
    period_cost = fields.Selection([('month', _('Month')), ('quarter', _('Quarter')), ('year', _('Year'))], default='month')
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id', string='Currency')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Done'),
    ], string='Status', default='draft',
        copy=False, index=True, readonly=True, store=True, tracking=True,
        help=" * Draft: The calculate period is not yet.\n"
             " * Done: The calculate period has been processed.")

    cost_product_ids = fields.Many2many('product.product', 'stock_cost_product_rel')

    @api.model
    def _default_most_recent(self):
        stock_calculate_ids = self.env['stock.calculate.cost']. \
            search(
            [('company_id', '=', self.env.company.id), ('branch_id', '=', self.env.user.employee_id.branch_id.id)])
        most_recent = None
        for line in stock_calculate_ids:
            if not most_recent or line.write_date > most_recent:
                most_recent = line.write_date
        self.most_recent = most_recent
        return most_recent

    @api.onchange('most_recent')
    def _onchange_most_recent(self):
        msg = _('The last calculated: ') + _('No data')
        if self.most_recent:
            msg = _('The last calculated: ') + self.most_recent.strftime("%d-%m-%Y %H:%M:%S")
        self.most_recent_display = msg

    most_recent = fields.Datetime(default=_default_most_recent, store=True)
    most_recent_display = fields.Char(store=False)

    def get_first_last_date_of_month(self, year, month):
        today = datetime.date(datetime.now())
        date_range = calendar.monthrange(year, month)
        return [today.replace(day=1, month=month, year=year), today.replace(day=date_range[1], month=month, year=year)]

    @api.onchange('period')
    def _onchange_period(self):
        if not self.period or not self.period:
            return
        today = datetime.date(datetime.now())
        if self.period.value[0] == 'd':
            # day
            self.date_from = self.date_to = today
            if len(self.period.value) > 1:
                if self.period.value[1] == '+':
                    self.date_from = self.date_to = today + timedelta(days=1)
                elif self.period.value[1] == '-':
                    self.date_from = self.date_to = today + timedelta(days=-1)
        elif self.period.value[0] == 'w':
            # week
            if len(self.period.value) > 1:
                if self.period.value[1] == '+':
                    today += timedelta(days=7)
                elif self.period.value[1] == '-':
                    today += timedelta(days=-7)
            self.date_from = today - timedelta(days=today.weekday())
            self.date_to = self.date_from + timedelta(days=6)
        elif self.period.value[0] == 'm':
            # month
            month = today.month
            if len(self.period.value) > 1:
                if self.period.value[1] == '+':
                    month += 1
                elif self.period.value[1] == '-':
                    month -= 1
                elif self.period.value[1:len(self.period.value)].isnumeric():
                    month = int(self.period.value[1:len(self.period.value)])
            arr_date = self.get_first_last_date_of_month(today.year, month)
            self.date_from = arr_date[0]
            self.date_to = arr_date[1]
        elif self.period.value[0] == 'q':
            # quarter
            if len(self.period.value) > 1:
                if self.period.value[1] == '+':
                    today = self.add_months(today, 3)
                elif self.period.value[1] == '-':
                    today = self.add_months(today, -3)
                elif self.period.value[1].isnumeric():
                    today = today.replace(month=int(self.period.value[1]) * 3)
            arr_date = self.get_quarter_date(today.year, today.month)
            self.date_from = arr_date[0]
            self.date_to = arr_date[1]
        elif self.period.value[0] == 'y':
            # year
            year = today.year
            if len(self.period.value) > 1:
                if self.period.value[1] == '+':
                    year += 1
                elif self.period.value[1] == '-':
                    year -= 1
            self.date_from = today.replace(day=1, month=1, year=year)
            self.date_to = today.replace(day=31, month=12, year=year)
            if len(self.period.value) > 1:
                if self.period.value[1] == 'f':
                    self.date_from = today.replace(day=1, month=1, year=year)
                    self.date_to = today.replace(day=30, month=6, year=year)
                elif self.period.value[1] == 'l':
                    self.date_from = today.replace(day=1, month=7, year=year)
                    self.date_to = today.replace(day=31, month=12, year=year)
        # if value is from beginning
        self.from_beginning()

    def get_quarter_date(self, year, month):
        date = datetime.now().replace(month=month, year=year)
        current_quarter = math.floor((date.month - 1) / 3) + 1
        first_date = datetime(date.year, 3 * current_quarter - 2, 1)
        last_date = datetime(date.year, 3 * current_quarter, calendar.monthrange(date.year, 3 * current_quarter)[1])
        return [first_date, last_date]

    def add_months(self, sourcedate, months):
        month = sourcedate.month - 1 + months
        year = sourcedate.year + month // 12
        month = month % 12 + 1
        day = min(sourcedate.day, calendar.monthrange(year, month)[1])
        return sourcedate.replace(year=year, month=month, day=day)

    def from_beginning(self):
        if len(self.period.value) > 1:
            if self.period.value[1] == 'b':
                self.date_to = datetime.date(datetime.now())

    def calculate_price_period(self, vals, branch_id, date_from=False, date_to=False, product_ids=False, cost_stock=False,
                               is_in_period=False, by_lot=False, is_immediately=False, period_past=False):
        price_dict = {}
        domain = [('state', '=', 'done')]
        if is_in_period:
            domain.extend([('picking_id.date', '>=', date_from), ('picking_id.date', '<=', date_to)])
        else:
            domain.append(('picking_id.date', '<', date_from))
        # get move history
        domain.extend([('branch_id', '=', branch_id),
                       ('company_id', '=', self.env.company.id),
                       ('picking_id.state', '=', 'done')])
        if is_in_period:
            # in period
            if cost_stock and not is_immediately:
                domain.append('|')
            if not is_immediately:
                domain.append('|')
            domain.extend(['|', '&', ('picking_code', '=', 'incoming'),
                           ('picking_id.picking_type_id.movement_type_id.value', '!=', 'A+'),
                           '&', ('picking_code', '=', 'mrp_operation'),
                           ('picking_id.picking_type_id.movement_type_id.value', '=', 'P+')
                           ])
            if not is_immediately:
                domain.extend(['|', '&', ('picking_code', '=', 'outgoing'),
                               ('picking_id.picking_type_id.movement_type_id.value', 'in', ['R-', 'T-', 'A-'])])
                domain.extend(['&', ('picking_code', '=', 'mrp_operation'),
                               ('picking_id.picking_type_id.movement_type_id.value', '=', 'P-')])
            if cost_stock and not is_immediately:
                domain.append(('picking_code', '=', 'internal'))
        else:
            # past period
            if cost_stock:
                domain.append('|')
            domain.extend(['|', '|', '|', ('picking_code', '=', 'incoming'),
                           '&', ('picking_code', '=', 'mrp_operation'),
                           ('picking_id.picking_type_id.movement_type_id.value', '=', 'P+'),
                           ('picking_code', '=', 'outgoing'),
                           '&', ('picking_code', '=', 'mrp_operation'),
                           ('picking_id.picking_type_id.movement_type_id.value', '=', 'P-')
                           ])
            if cost_stock:
                domain.append(('picking_code', '=', 'internal'))
        if by_lot:
            domain.append(('lot_id', 'in', product_ids))
        else:
            domain.append(('product_id', 'in', product_ids))
        stock_move_line_history = self.env['stock.move.line'].search(domain)

        for move_line in stock_move_line_history:
            if by_lot:
                product_id = str(move_line.lot_id.id)
            else:
                product_id = str(move_line.product_id.id)
            if product_id not in price_dict.keys():
                price_dict.update({product_id: {}})
            product_price = price_dict.get(product_id)
            if cost_stock:
                if is_in_period:
                    product_price.update({str(move_line.location_dest_id.id): {'total_value': 0, 'total_quantity': 0}})
                else:
                    if move_line.location_dest_id.usage == 'internal':
                        product_price.update({str(move_line.location_dest_id.id): {'total_value': 0, 'total_quantity': 0}})
                    if move_line.location_id.usage == 'internal':
                        product_price.update(
                            {str(move_line.location_id.id): {'total_value': 0, 'total_quantity': 0}})
            else:
                price_dict.update({product_id: {'total_value': 0, 'total_quantity': 0}})

        stock_move_id = stock_move_line_history.move_id
        product_total_dict = {}
        lot_total_dict = {}
        for stock_move in stock_move_id:
            for stock_value_line in stock_move.stock_valuation_layer_ids:
                product_id = str(stock_value_line.product_id.id)
                if product_id not in product_total_dict.keys():
                    product_total_dict.update({product_id: {'total_value': 0, 'total_quantity': 0}})
                product_total_price = product_total_dict.get(product_id)
                sum_value = product_total_price.get('total_value') + stock_value_line.value
                sum_quantity = product_total_price.get('total_quantity') + stock_value_line.quantity
                product_total_price.update({'total_value': sum_value, 'total_quantity': sum_quantity})
            if by_lot:
                for lot in product_ids:
                    key_lot = str(lot)
                    dict_price = product_total_dict.get(str(stock_value_line.product_id.id))
                    if not dict_price or 'total_quantity' not in dict_price.keys() or dict_price['total_quantity'] == 0:
                        raise ValidationError(
                            'Product error id:' + str(stock_value_line.product_id.id) + ' name:' + stock_value_line.product_id.name)
                    unit_price = dict_price['total_value'] / dict_price['total_quantity']
                    move_line = stock_move.move_line_ids.filtered(lambda line: line.lot_id.id == lot)
                    if key_lot not in lot_total_dict.keys():
                        lot_total_dict.update({str(lot): {'total_value': 0,
                                                          'total_quantity': 0}})
                    lot_value = lot_total_dict.get(key_lot).get('total_value') + move_line.qty_done * unit_price
                    lot_qty = lot_total_dict.get(key_lot).get('total_quantity') + move_line.qty_done
                    lot_total_dict.update({key_lot: {'total_value': lot_value, 'total_quantity': lot_qty}})
        if not cost_stock:
            if by_lot:
                price_dict = lot_total_dict
            else:
                price_dict = product_total_dict
        else:
            for stock_move in stock_move_id:
                product_id = str(stock_move.product_id.id)
                product_dict = product_total_dict.get(product_id)
                for move_line in stock_move.move_line_ids:
                    if by_lot:
                        product_price = price_dict.get(str(move_line.lot_id.id))
                        product_dict = lot_total_dict.get(str(move_line.lot_id.id))
                    else:
                        product_price = price_dict.get(product_id)
                    if is_in_period:
                        product_price.update(self.calculate_total_quantity(product_price, product_dict, move_line, False))
                    else:
                        if move_line.location_dest_id.usage == 'internal':
                            product_price.update(self.calculate_total_quantity(product_price, product_dict, move_line, False))
                        if move_line.location_id.usage == 'internal':
                            product_price.update(self.calculate_total_quantity(product_price, product_dict, move_line, True))
        if is_immediately and not stock_move_id:
            price_dict = period_past
        if is_in_period:
            price_dict.update({'date_from': date_from, 'date_to': date_to})
        else:
            price_dict.update({'date_to': date_from})
        return price_dict

    def calculate_total_quantity(self, product_price, product_dict, move_line, is_receipt=False):
        key_location = ''
        line_sum_value = 0
        if is_receipt:
            key_location = str(move_line.location_id.id)
        else:
            key_location = str(move_line.location_dest_id.id)
        location_price = product_price.get(key_location)
        if not product_dict or 'total_quantity' not in product_dict.keys() or product_dict['total_quantity'] == 0:
            raise ValidationError('Product error id: ' + str(move_line.product_id.id) + ' product name : ' + move_line.product_id.name)
        line_sum_value = location_price.get('total_value') + (product_dict['total_value']/product_dict['total_quantity']) * move_line.qty_done
        line_sum_quantity = location_price.get('total_quantity') + move_line.qty_done
        return {key_location: {'total_value': line_sum_value, 'total_quantity': line_sum_quantity}}

    def unique(self, list):
        unique_list = []
        for x in list:
            if x not in unique_list:
                unique_list.append(x)
        return unique_list

    def filter_list_price_get_location(self, period_past_cost, period_cost, product_id):
        arr_location_id = []
        for pr_id in product_id:
            if period_cost and period_cost.get(str(pr_id)) and period_cost.get(str(pr_id)).keys():
                arr_location_id.extend(period_cost.get(str(pr_id)).keys())
            if period_past_cost and period_past_cost.get(str(pr_id)) and period_past_cost.get(str(pr_id)).keys():
                arr_location_id.extend(period_past_cost.get(str(pr_id)).keys())
        return self.unique(arr_location_id)

    def calculate_previous_period_price(self, key, period_past_cost, period_cost, price_dict):
        key = str(key)
        total_value = 0
        total_quantity = 0
        if period_past_cost and key in period_past_cost.keys() and 'total_value' in period_past_cost[key].keys() and 'total_quantity' in period_past_cost[key].keys():
            total_value += period_past_cost[key]['total_value']
            total_quantity += period_past_cost[key]['total_quantity']
        if period_cost and key in period_cost.keys() and 'total_value' in period_cost[key].keys() and 'total_quantity' in period_cost[key].keys():
            total_value += period_cost[key]['total_value']
            total_quantity += period_cost[key]['total_quantity']
        price_dict.update({key: {'total_value': total_value, 'total_quantity': total_quantity}})

    def calculate_previous_period(self, product_ids, period_past_cost, period_cost, date_from, cost_stock=False):
        price_dict = {}
        location = []
        if cost_stock:
            location = self.filter_list_price_get_location(period_past_cost, period_cost, product_ids)
        price_dict.update({'date_to': date_from})
        for product_id in product_ids:
            if cost_stock:
                if str(product_id) not in price_dict.keys():
                    price_dict.update({str(product_id): {}})
                for location_id in location:
                    period_past_cost_location = period_past_cost.get(str(product_id))
                    period_period_cost_location = period_cost.get(str(product_id))
                    self.calculate_previous_period_price(str(location_id), period_past_cost_location,
                                                         period_period_cost_location, price_dict.get(str(product_id)))
            else:
                self.calculate_previous_period_price(str(product_id), period_past_cost, period_cost, price_dict)
        return price_dict

    def update_value_layer_accounting(self, value_layer, out_price_unit, total, quantity):
        self.env['stock.valuation.layer'].browse(value_layer.id).update({
            'unit_cost': out_price_unit,
            'value': total
        })
        update_value = []
        account_move_line = value_layer.account_move_id.line_ids
        for account_line in account_move_line:
            if account_line.balance < 0:
                update_value.append([1, account_line.id, {
                    'credit': total * -1,
                    'quantity': quantity
                }])
            else:
                update_value.append([1, account_line.id, {
                    'debit': total * -1,
                    'quantity': quantity
                }])
        if update_value:
            vals_account_line = {'line_ids': update_value}
            value_layer.account_move_id.update(vals_account_line)

    def update_move_line(self, move_update_ids, price_dict_first_period, period_price, cost_stock, is_immediately=False):
        price_updated = []
        for move in move_update_ids:
            value_layer_ids = move.stock_valuation_layer_ids
            for value_layer in value_layer_ids:
                product_id = str(value_layer.product_id.id)
                location_id = str(move.location_id.id)
                value_first = quantity_first = value_period = quantity_period = 0
                price_first_period = {}
                price_in_period = {}
                if cost_stock:
                    if price_dict_first_period and price_dict_first_period.get(product_id):
                        price_first_period = price_dict_first_period.get(product_id).get(location_id)
                    if period_price and period_price.get(product_id):
                        price_in_period = period_price.get(product_id).get(location_id)
                else:
                    if price_dict_first_period:
                        price_first_period = price_dict_first_period.get(product_id)
                    if period_price:
                        price_in_period = period_price.get(product_id)
                if price_first_period:
                    if 'total_value' in price_first_period.keys() and 'total_quantity' in price_first_period.keys():
                        value_first = price_first_period.get('total_value')
                        quantity_first = price_first_period.get('total_quantity')
                if price_in_period:
                    if 'total_value' in price_in_period.keys() and 'total_quantity' in price_in_period.keys():
                        value_period = price_in_period.get('total_value')
                        quantity_period = price_in_period.get('total_quantity')
                if quantity_period + quantity_first == 0:
                    raise ValidationError('Product error id:' + str(move.product_id.id) + ' name:' + move.product_id.name)
                out_price_unit = (value_period + value_first) / (quantity_period + quantity_first)
                total = value_layer.quantity * out_price_unit
                if cost_stock:
                    price_updated.append({product_id: {location_id: {'total_value': total, 'total_quantity': value_layer.quantity}}})
                else:
                    price_updated.append(
                        {product_id: {'total_value': total, 'total_quantity': value_layer.quantity}})
                self.update_value_layer_accounting(value_layer, out_price_unit, total, value_layer.quantity)
        return price_updated

    def query_update_move_line(self, vals, branch_id, date_from, date_to, product_ids, cost_stock=False, is_acvo=False):
        domain = [
            ('picking_id.state', '=', 'done'),
            ('state', '=', 'done'),
            ('picking_id.date', '>=', date_from),
            ('picking_id.date', '<=', date_to),
            ('branch_id', '=', branch_id),
            ('company_id', '=', self.env.company.id), ('product_id', 'in', product_ids)
            ]
        if not cost_stock and is_acvo:
            domain.append('|')
        domain.extend(['|', '&', ('picking_code', '=', 'outgoing'),
                      ('picking_id.picking_type_id.movement_type_id.value', 'not in', ['R-', 'T-', 'A-']),
                      '&', ('picking_code', '=', 'mrp_operation'),
                       ('picking_id.picking_type_id.movement_type_id.value', '=', 'P-')])
        if not cost_stock and is_acvo:
            domain.append(('picking_code', '=', 'internal'))
        return self.env['stock.move'].search(domain)

    def calculate_avco_ep(self, vals, branch_id, date_from, date_to, product_ids):
        if not product_ids:
            return
        period_cost = []
        period_past_cost = []
        to_period = date_to
        from_period = date_from
        month_delta = 0
        cost_stock = vals['cost_stock'] == 'by_location'
        # split period
        if vals['period_cost'] == 'month':
            month_delta = relativedelta(months=1)
        elif vals['period_cost'] == 'quarter':
            month_delta = relativedelta(months=3)
        elif vals['period_cost'] == 'year':
            month_delta = relativedelta(months=12)
        while from_period <= to_period:
            if vals['period_cost'] == 'month':
                arr_date = self.get_first_last_date_of_month(from_period.year, from_period.month)
            elif vals['period_cost'] == 'quarter':
                arr_date = self.get_quarter_date(from_period.year, from_period.month)
            elif vals['period_cost'] == 'year':
                arr_date = [from_period.replace(day=1, month=1, year=from_period.year),
                            from_period.replace(day=31, month=12, year=from_period.year)]
            period_cost.append({'date_from': datetime.combine(arr_date[0], datetime.min.time()),
                                'date_to': datetime.combine(arr_date[1], datetime.max.time())})
            from_period += month_delta
        for i, period_cost_line in enumerate(period_cost):
            period_date_from = period_cost_line['date_from']
            period_date_to = period_cost_line['date_to']

            # calculate this period
            period_cost_line.update(self.calculate_price_period(vals, branch_id, period_date_from, period_date_to,
                                                                product_ids, cost_stock=cost_stock,
                                                                is_in_period=True))
            # calculate past period
            if i == 0:
                period_past_cost.append(self.calculate_price_period(vals, branch_id, period_date_from, date_to, product_ids,
                                                                    cost_stock=cost_stock, is_in_period=False))
            else:
                period_past_cost.append(
                    self.calculate_previous_period(product_ids, period_past_cost[i - 1], period_cost[i - 1],
                                                   period_date_from, True))

            move_update_ids = self.query_update_move_line(vals, branch_id, period_date_from, period_date_to, product_ids,
                                                          cost_stock=cost_stock, is_acvo=True)
            if not move_update_ids:
                continue
            # update stock
            self.update_move_line(move_update_ids, period_past_cost[i], period_cost_line,
                                  cost_stock)

    def calculate_avco(self, vals, branch_id, date_from, date_to, product_ids):
        if not product_ids:
            return
        for product_id in product_ids:
            period_past_cost = []
            period_cost = []
            cost_stock = vals['cost_stock'] == 'by_location'
            move_update_ids = self.query_update_move_line(vals, branch_id, date_from, date_to, [product_id], cost_stock=cost_stock,
                                                          is_acvo=True)
            if not move_update_ids:
                return
            for i, move in enumerate(move_update_ids):
                domain = [
                    ('picking_id.date', '<=', move.picking_id.date - timedelta(0, 1)),
                    ('state', '=', 'done'),
                    ('picking_id.state', '=', 'done'),
                    ('branch_id', '=', branch_id),
                    ('company_id', '=', self.env.company.id), ('picking_code', '=', 'incoming'),
                    ('product_id', '=', product_id)]
                move_receipt = self.env['stock.move'].search(domain)
                if not move_receipt:
                    continue
                # get nearly receipt
                move_max_receipt = move_receipt[0]
                for move_receipt_line in move_receipt:
                    if move_receipt_line.picking_accounting_date > move_max_receipt.picking_accounting_date:
                        move_max_receipt = move_receipt_line

                # calculate past period and this period
                if i == 0:
                    period_past_cost.append(self.calculate_price_period(vals, branch_id, move_max_receipt.picking_accounting_date + timedelta(0, 1), date_to, move.product_id.ids,
                                                                        cost_stock=cost_stock, is_in_period=False))
                    period_cost.append({'date_from': move_max_receipt.picking_accounting_date,
                                        'date_to': move.picking_accounting_date})
                else:
                    period_cost.append(self.calculate_price_period(vals, branch_id, period_cost[i - 1].get('date_to'),
                                                                   move.picking_accounting_date - timedelta(0, 1),
                                                                   move.product_id.ids, cost_stock=cost_stock,
                                                                   is_in_period=True, by_lot=False, is_immediately=True,
                                                                   period_past = period_past_cost[i-1]))
                    period_past_cost.append(
                        self.calculate_previous_period([product_id], period_past_cost[i - 1], period_cost[i],
                                                       period_cost[i - 1].get('date_to'),
                                                       cost_stock=cost_stock))
                # update stock move
                if i == 0:
                    arr_updated_value = self.update_move_line(move, period_past_cost[i], period_cost[i],
                                          cost_stock, is_immediately=True)
                else:
                    arr_updated_value = self.update_move_line(move, period_past_cost[i], None,
                                                              cost_stock, is_immediately=True)

                # calculate period after update stock move
                for updated_value in arr_updated_value:
                    for key_prd in period_past_cost[i].keys():
                        if key_prd in updated_value.keys():
                            if cost_stock:
                                period = period_past_cost[i].get(key_prd)
                                updated = updated_value.get(key_prd)
                                for key_location in period:
                                    if key_location in updated:
                                        period.get(key_location)['total_value'] += updated.get(key_location)['total_value']
                                        period.get(key_location)['total_quantity'] += updated.get(key_location)['total_quantity']
                            else:
                                period_past_cost[i].get(key_prd)['total_value'] += updated_value.get(key_prd)['total_value']
                                period_past_cost[i].get(key_prd)['total_quantity'] += updated_value.get(key_prd)['total_quantity']


    def move_to_array(self, move_receipt, product_id, location_id, by_lot=False):
        arr = []
        arr_lot = []
        move_calculate = []
        if location_id:
            if by_lot:
                move_calculate = move_receipt.filtered(
                    lambda move: int(product_id) in move.move_line_ids.lot_id.ids and str(move.location_dest_id.id) == location_id)
            else:
                move_calculate = move_receipt.filtered(lambda move: str(move.product_id.id) == product_id and str(move.location_dest_id.id) == location_id)
        else:
            if by_lot:
                move_calculate = move_receipt.filtered(lambda move: int(product_id) in move.move_line_ids.lot_id.ids)
            else:
                move_calculate = move_receipt.filtered(lambda move: str(move.product_id.id) == product_id)
        for move in move_calculate:
            total_value = total_quantity = 0
            for layer in move.stock_valuation_layer_ids:
                total_value += layer.value
                total_quantity += layer.quantity
            if by_lot:
                arr.append({'move': move.id, 'date': move.picking_id.date, 'quantity': total_quantity, 'total_value': total_value})
            else:
                arr.append({'date': move.picking_id.date, 'quantity': total_quantity, 'total_value': total_value})
        if by_lot:
            move_line_calculated = []
            if location_id:
                move_lines = move_calculate.move_line_ids
                move_line_calculated = move_lines.filtered(
                    lambda move_line: str(move_line.lot_id.id) == product_id and str(move_line.location_dest_id.id) == location_id)
            else:
                move_lines = move_calculate.move_line_ids
                move_line_calculated = move_lines.filtered(
                    lambda move_line: str(move_line.lot_id.id) == product_id)
            for line in move_line_calculated:
                total_value = total_quantity = 0
                for price in arr:
                    if price.get('move') == line.move_id.id:
                        if not price or price.get('quantity') == 0:
                            raise ValidationError('Product error id:' + str(move.product_id.id) + ' name:' + str(move.product_id.name))
                        unit_price = price.get('total_value') / price.get('quantity')
                        total_value += unit_price * line.qty_done
                        total_quantity += line.qty_done
                arr_lot.append({'date': line.move_id.picking_id.date, 'quantity': total_quantity, 'total_value': total_value})
        if by_lot:
            arr = arr_lot
        return arr

    def execute_calculate_remain_receipt_past_period(self, move_receipt, period_past_cost, product_key, location_id, by_lot=False):
        arr_cal = []
        arr_receipt = []
        qdk = vdk = 0
        if location_id:
            qdk = period_past_cost[product_key][location_id]['total_quantity']
            vdk = period_past_cost[product_key][location_id]['total_value']
            arr_receipt.extend(self.move_to_array(move_receipt, product_key, location_id, by_lot))
        else:
            qdk = period_past_cost[product_key]['total_quantity']
            vdk = period_past_cost[product_key]['total_value']
            arr_receipt.extend(self.move_to_array(move_receipt, product_key, None, by_lot))
        arr_receipt.sort(reverse=True, key=lambda x: x['date'])
        for receipt in arr_receipt:
            if qdk <= 0:
                break
            if receipt['quantity'] < qdk:
                qdk -= receipt['quantity']
                vdk -= receipt['total_value']
            else:
                receipt['quantity'] = qdk
                receipt['total_value'] = vdk
                qdk -= receipt['quantity']
                vdk -= receipt['total_value']
            arr_cal.insert(0, receipt)
        return arr_cal

    def calculate_remain_receipt_past_period(self, period_past_cost, move_receipt, cost_stock, product_ids, by_lot=False):
        result = {}
        prd_quantity = []
        arr_location = []
        if cost_stock:
            arr_location = self.filter_list_price_get_location(period_past_cost, None, product_ids)
        for product_key in period_past_cost:
            if product_key == 'date_to':
                continue
            if product_key not in result.keys():
                if cost_stock:
                    result.update({product_key: {}})
                else:
                    result.update({product_key: []})
            if cost_stock:
                for location in arr_location:
                    if location not in period_past_cost.get(product_key):
                        continue
                    if location not in result.get(product_key).keys():
                        result.get(product_key).update({location: []})
                    result.get(product_key).get(location).extend(self.execute_calculate_remain_receipt_past_period(move_receipt, period_past_cost,
                                                                      product_key, location, by_lot))
            else:
                result.get(product_key).extend(self.execute_calculate_remain_receipt_past_period(move_receipt, period_past_cost, product_key, None, by_lot))
        return result

    def calculate_fifo_move_out(self, arr_receipt, move_update_ids, cost_stock):
        arr_out = []
        for move in move_update_ids:
            product_key = str(move.product_id.id)
            location_key = str(move.location_id.id)
            move_out = {'id': move.id, 'quantity': 0, 'total_value': 0}
            qx = move.quantity_done
            receipt_calculate = []
            if arr_receipt and arr_receipt.get(product_key):
                if cost_stock:
                    receipt_calculate = arr_receipt.get(product_key).get(location_key)
                else:
                    receipt_calculate = arr_receipt.get(product_key)
            for receipt in receipt_calculate:
                if receipt['quantity'] < qx:
                    value = move_out['total_value'] + receipt['total_value']
                    quantity = move_out['quantity'] + receipt['quantity']
                    move_out.update({'quantity': quantity, 'total_value': value})
                    qx -= receipt['quantity']
                    receipt['total_value'] = 0
                    receipt['quantity'] = 0
                else:
                    value = (receipt['total_value'] / receipt['quantity']) * qx
                    quantity = qx
                    value_out = move_out['total_value'] + value
                    quantity_out = move_out['quantity'] + quantity
                    move_out.update({'quantity': quantity_out, 'total_value': value_out})
                    value_remain = receipt['total_value'] - value
                    quantity_remain = receipt['quantity'] - quantity
                    receipt.update({'quantity': quantity_remain, 'total_value': value_remain})
                    qx = 0
                if qx <= 0:
                    arr_out.append(move_out)
                    break
        return arr_out

    def update_move_line_fifo(self, arr_receipt, move_update_ids, cost_stock):
        arr_out = self.calculate_fifo_move_out(arr_receipt, move_update_ids, cost_stock)
        for move_out in arr_out:
            move = move_update_ids.filtered(lambda x: x.id == move_out['id'])
            for value_layer in move.stock_valuation_layer_ids:
                if not move_out or move_out['quantity'] == 0:
                    raise ValidationError('Product error id:' + str(move.product_id.id) + ' name:' + move.product_id.name)
                self.update_value_layer_accounting(value_layer, move_out['total_value'] / move_out['quantity'],
                                                   move_out['total_value'] * -1, move_out['quantity'])

    def calculate_fifo(self, vals, branch_id, date_from, date_to, product_ids):
        cost_stock = vals['cost_stock'] == 'by_location'
        if not product_ids:
            return
        move_update_ids = self.query_update_move_line(vals, branch_id, date_from, date_to, product_ids, cost_stock=cost_stock,
                                                      is_acvo=False)
        if not move_update_ids:
            return
        receipt_past = {}
        receipt_in_period = {}
        arr_location = move_update_ids.location_id.ids
        period_past_cost = self.calculate_price_period(vals, branch_id, date_from, date_to,
                                        product_ids,
                                        cost_stock=cost_stock, is_in_period=False)
        domain = [
            ('picking_id.date', '<=', date_to),
            ('picking_id.state', '=', 'done'),
            ('state', '=', 'done'),
            ('branch_id', '=', branch_id),
            ('company_id', '=', self.env.company.id),
            ('product_id', 'in', product_ids),
            '|', ('picking_code', '=', 'incoming'),
            '&', ('picking_code', '=', 'mrp_operation'),
            ('picking_id.picking_type_id.movement_type_id.value', '=', 'P+')
            ]
        move_receipt = self.env['stock.move'].search(domain)
        # calculate past receipt
        receipt_past = self.calculate_remain_receipt_past_period(period_past_cost, move_receipt.filtered(lambda move: move.picking_accounting_date < date_from),
                                                                cost_stock, product_ids)
        move_in_period = move_receipt.filtered(lambda move: move.picking_accounting_date >= date_from)

        # calculate receipt in period
        for key_product in product_ids:
            product_id = str(key_product)
            if product_id not in receipt_in_period.keys():
                if cost_stock:
                    receipt_in_period.update({product_id: {}})
                else:
                    receipt_in_period.update({product_id: []})
            if cost_stock:
                for key_location in arr_location:
                    location = str(key_location)
                    move_arr = self.move_to_array(move_in_period, str(product_id), str(location))
                    if not move_arr:
                        continue
                    if location not in receipt_in_period.get(product_id):
                        receipt_in_period.get(product_id).update({location: []})
                    receipt_in_period.get(product_id).get(location).extend(move_arr)
                    receipt_in_period.get(product_id).get(location).sort(key=lambda x: x['date'])
                    if product_id not in receipt_past.keys():
                        receipt_past.update({product_id: {location: []}})
                    if location not in receipt_past.get(product_id):
                        receipt_past.get(product_id).update({location: []})
                    receipt_past.get(product_id).get(location).extend(receipt_in_period.get(product_id).get(location))
            else:
                move_arr = self.move_to_array(move_in_period, str(product_id), None)
                if not move_arr:
                    continue
                receipt_in_period.get(product_id).extend(move_arr)
                receipt_in_period.get(product_id).sort(key=lambda x: x['date'])
                if product_id not in receipt_past.keys():
                    receipt_past.update({product_id: []})
                receipt_past.get(product_id).extend(receipt_in_period.get(product_id))
        # update stock move
        self.update_move_line_fifo(receipt_past, move_update_ids, cost_stock)

    def calculate_spec_move_out(self, arr_receipt, move_update_ids, cost_stock):
        arr_out_lot = []
        for move in move_update_ids:
            move_out_lot = {'id': move.id, 'quantity': 0, 'total_value': 0}
            for move_line in move.move_line_ids:
                lot_key = str(move_line.lot_id.id)
                location_key = str(move.location_id.id)
                move_out = {'id': move_line.id, 'quantity': 0, 'total_value': 0}
                qx = move_line.qty_done
                receipt_calculate = []
                if cost_stock:
                    receipt_calculate = arr_receipt.get(lot_key).get(location_key)
                else:
                    receipt_calculate = arr_receipt.get(lot_key)
                if not receipt_calculate:
                    continue
                for receipt in receipt_calculate:
                    if receipt['quantity'] < qx:
                        value = move_out['total_value'] + receipt['total_value']
                        quantity = move_out['quantity'] + receipt['quantity']
                        move_out.update({'quantity': quantity, 'total_value': value})
                        qx -= receipt['quantity']
                        receipt['total_value'] = 0
                        receipt['quantity'] = 0
                    else:
                        value = (receipt['total_value'] / receipt['quantity']) * qx
                        quantity = qx
                        value_out = move_out['total_value'] + value
                        quantity_out = move_out['quantity'] + quantity
                        move_out.update({'quantity': quantity_out, 'total_value': value_out})
                        value_remain = receipt['total_value'] - value
                        quantity_remain = receipt['quantity'] - quantity
                        receipt.update({'quantity': quantity_remain, 'total_value': value_remain})
                        qx = 0
                    if qx <= 0:
                        move_value = move_out_lot['total_value'] + move_out['total_value']
                        move_quantity = move_out_lot['quantity'] + move_out['quantity']
                        move_out_lot.update({'quantity': move_quantity, 'total_value': move_value})
                        break
            arr_out_lot.append(move_out_lot)
        return arr_out_lot

    def update_move_line_spec(self, arr_receipt, move_update_ids, cost_stock):
        arr_out = self.calculate_spec_move_out(arr_receipt, move_update_ids, cost_stock)
        for move_out in arr_out:
            move = move_update_ids.filtered(lambda x: x.id == move_out['id'])
            for value_layer in move.stock_valuation_layer_ids:
                self.update_value_layer_accounting(value_layer, move_out['total_value'] / move_out['quantity'],
                                                   move_out['total_value'] * -1, move_out['quantity'])

    def calculate_specific(self, vals, branch_id, date_from, date_to, product_ids):
        cost_stock = vals['cost_stock'] == 'by_location'
        if not product_ids:
            return
        move_update_ids = self.query_update_move_line(vals, branch_id, date_from, date_to, product_ids, cost_stock=cost_stock,
                                                      is_acvo=False)
        if not move_update_ids:
            return
        lot_ids = move_update_ids.move_line_ids.lot_id.ids
        receipt_past = {}
        receipt_in_period = {}
        arr_location = move_update_ids.location_id.ids
        period_past_cost = self.calculate_price_period(vals, branch_id, date_from, date_to,
                                                       lot_ids,
                                                       cost_stock=cost_stock, is_in_period=False, by_lot=True)
        domain = [
            ('picking_id.date', '<=', date_to),
            ('picking_id.state', '=', 'done'),
            ('state', '=', 'done'),
            ('branch_id', '=', branch_id),
            ('company_id', '=', self.env.company.id), ('picking_code', '=', 'incoming'),
            ('product_id', 'in', product_ids),
            '|', ('move_line_ids.lot_id', 'in', move_update_ids.move_line_ids.lot_id.ids),
            '&', ('picking_code', '=', 'mrp_operation'),
            ('picking_id.picking_type_id.movement_type_id.value', '=', 'P+')
            ]
        move_receipt = self.env['stock.move'].search(domain)

        # calculate receipt past
        receipt_past = self.calculate_remain_receipt_past_period(period_past_cost, move_receipt.filtered(
            lambda move: move.picking_accounting_date < date_from),
                                                                 cost_stock, lot_ids, by_lot=True)
        move_in_period = move_receipt.filtered(lambda move: move.picking_accounting_date >= date_from)

        # calculate in period
        for key_lot in lot_ids:
            lot_id = str(key_lot)
            if lot_id not in receipt_in_period.keys():
                if cost_stock:
                    receipt_in_period.update({lot_id: {}})
                else:
                    receipt_in_period.update({lot_id: []})
            if cost_stock:
                for key_location in arr_location:
                    location = str(key_location)
                    move_arr = self.move_to_array(move_in_period, str(lot_id), str(location), True)
                    if not move_arr:
                        continue
                    if location not in receipt_in_period.get(lot_id):
                        receipt_in_period.get(lot_id).update({location: []})
                    receipt_in_period.get(lot_id).get(location).extend(move_arr)
                    receipt_in_period.get(lot_id).get(location).sort(key=lambda x: x['date'])
                    if lot_id not in receipt_past.keys():
                        receipt_past.update({lot_id: {location: []}})
                    if location not in receipt_past.get(lot_id):
                        receipt_past.get(lot_id).update({location: []})
                    receipt_past.get(lot_id).get(location).extend(receipt_in_period.get(lot_id).get(location))
            else:
                move_arr = self.move_to_array(move_in_period, str(lot_id), None, True)
                if not move_arr:
                    continue
                receipt_in_period.get(lot_id).extend(move_arr)
                receipt_in_period.get(lot_id).sort(key=lambda x: x['date'])
                if lot_id not in receipt_past.keys():
                    receipt_past.update({lot_id: []})
                receipt_past.get(lot_id).extend(receipt_in_period.get(lot_id))
        # update stock move
        if not receipt_past:
            return
        self.update_move_line_spec(receipt_past, move_update_ids, cost_stock)

    @api.model
    def create(self, vals):
        date_from = datetime.combine(datetime.strptime(vals['date_from'].split(' ')[0], "%Y-%m-%d"), time(0, 0, 0))
        date_to = datetime.combine(datetime.strptime(vals['date_to'].split(' ')[0], "%Y-%m-%d"), time(23, 59, 59))
        branch_ids = []
        product_objs = []
        if vals['target_mode'] == 'selected_items':
            product_ids = vals['cost_product_ids'][0][2]
            product_objs = self.env['product.product'].browse(product_ids)
        else:
            product_objs = self.env['product.product'].search([('active', '=', True)])
        product_avco_ep = product_objs.filtered(
            lambda product: product.categ_id.avco_type == 'avco_ep' and product.categ_id.property_cost_method == 'average')
        product_avco = product_objs.filtered(
            lambda product: product.categ_id.avco_type == 'avco' and product.categ_id.property_cost_method == 'average')
        product_fifo = product_objs.filtered(lambda product: product.categ_id.property_cost_method == 'fifo')
        product_specific = product_objs.filtered(lambda product: product.categ_id.property_cost_method == 'specific')
        if vals['branch_ids'] and vals['branch_ids'][0] and vals['branch_ids'][0][2]:
            branch_ids = vals['branch_ids'][0][2]
        for branch_id in branch_ids:
            self.calculate_avco_ep(vals, branch_id, date_from, date_to, product_avco_ep.ids)
            self.calculate_avco(vals, branch_id, date_from, date_to, product_avco.ids)
            self.calculate_fifo(vals, branch_id, date_from, date_to, product_fifo.ids)
            self.calculate_specific(vals, branch_id, date_from, date_to, product_specific.ids)
        vals.update({'state': 'done'})
        return super(StockCalculateCost, self).create(vals)
