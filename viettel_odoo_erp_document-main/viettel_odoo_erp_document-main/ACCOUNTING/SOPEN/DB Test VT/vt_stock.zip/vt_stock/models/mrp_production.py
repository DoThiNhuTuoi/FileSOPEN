# -*- coding: utf-8 -*-

from odoo import models


class MrpProduction(models.Model):
    _inherit = "mrp.production"

    def name_get(self):
        result = []
        for po in self:
            name = po.name + ' - ' + str(po.date_planned_start.date())
            result.append((po.id, name))
        return result
