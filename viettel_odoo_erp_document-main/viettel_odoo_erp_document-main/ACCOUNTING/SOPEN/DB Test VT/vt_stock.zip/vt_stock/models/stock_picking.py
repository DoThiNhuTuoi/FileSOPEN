# -*- coding: utf-8 -*-

import logging
import json
from datetime import datetime, time, timedelta

from odoo import _, models, api, fields
from odoo.exceptions import ValidationError
from odoo.tools import float_is_zero
from odoo.exceptions import UserError

from psycopg2 import IntegrityError

_logger = logging.getLogger(__name__)

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    # Field on screen
    # Left side
    def get_in_out_type(self, picking_type=False, default_picking_type_code=False):
        if default_picking_type_code == 'incoming' or (picking_type and (picking_type.code == 'incoming' or (
                picking_type.code == 'mrp_operation' and picking_type.movement_type_id.value == 'P+'))):
            return 'in'
        elif default_picking_type_code == 'outgoing' or (picking_type and (
                picking_type.code == 'outgoing' or (picking_type.code == 'mrp_operation' and picking_type.movement_type_id.value == 'P-'))):
            return 'out'
        elif default_picking_type_code == 'internal' or (picking_type and picking_type.code == 'internal'):
            return 'internal'

    @api.onchange('picking_type_id')
    def _get_stock_picking_Id(self):
        for move in self.move_lines:
            move.picking_type_id = self.picking_type_id
            move.in_out_type = self.get_in_out_type(picking_type=move.picking_type_id)

        default_code = default_value = branch_id = None
        if 'default_picking_type_code' in self.env.context and self.env.context['default_picking_type_code']:
            # from menu receipt, deliver, internal
            default_code = self.env.context['default_picking_type_code']
        branch_id = self.branch_id.id
        if self.picking_type_code:
            # from overview
            default_code = self.picking_type_code
            default_value = self.movement_type_value

        # init domain
        domain = {}
        if default_code and ('default_picking_type_id' in self.env.context or
                             'default_picking_type_code' in self.env.context):
            if default_code == 'incoming' or \
                    (default_code == 'mrp_operation' and default_value == 'P+'):
                domain = {'domain': {'picking_type_id': self._domain_picking_Id(branch_id)}}
            elif default_code == 'outgoing' or \
                    (default_code == 'mrp_operation' and default_value == 'P-'):
                domain = {'domain': {'picking_type_id': self._domain_picking_Id(branch_id)}}
            else:
                domain = {'domain': {'picking_type_id': self._domain_picking_Id(branch_id)}}
        if self.picking_type_id and 'domain' in domain.keys():
            domain.get('domain').update({'location_id': [('company_id', '=', self.env.company.id)],
                                         'location_dest_id': [('company_id', '=', self.env.company.id)]})
            domain.get('domain').update({'location_id': [('branch_id', '=', branch_id)],
                                         'location_dest_id': [('branch_id', '=', branch_id)]})
        return domain

    def _domain_picking_Id(self, branch_id=False):
        # init domain
        default_code = default_value = None
        if 'default_picking_type_code' in self.env.context and self.env.context['default_picking_type_code']:
            # from menu receipt, deliver, internal
            default_code = self.env.context['default_picking_type_code']
        if self.picking_type_code:
            # from overview
            default_code = self.picking_type_code
            default_value = self.movement_type_value
            if not branch_id:
                branch_id = self.branch_id.id
        domain = []
        if default_code and ('default_picking_type_id' in self.env.context or
                             'default_picking_type_code' in self.env.context):
            if default_code == 'incoming' or \
                    (default_code == 'mrp_operation' and default_value == 'P+'):
                domain = ['&', '|', ('code', '=', 'incoming'),
                                                         '&', ('code', '=', 'mrp_operation'),
                                                         ('movement_type_id.value', '=', 'P+'),
                                                         ('company_id', '=', self.env.company.id)]
            elif default_code == 'outgoing' or \
                    (default_code == 'mrp_operation' and default_value == 'P-'):
                domain = ['&', '|', ('code', '=', 'outgoing'),
                                                         '&', ('code', '=', 'mrp_operation'),
                                                         ('movement_type_id.value', '=', 'P-'),
                                                         ('company_id', '=', self.env.company.id)]
            else:
                domain = [('code', '=', default_code), ('company_id', '=', self.env.company.id)]
        if branch_id:
            domain.append(('branch_id', '=', branch_id))
        return domain

    def _get_name_picking_id(self):
        inout_type = self.get_in_out_type(default_picking_type_code=self.default_picking_type_code)
        if inout_type == 'in':
            return 'Receive type'
        elif inout_type == 'out':
            return 'Delivery type'
        elif inout_type == 'internal':
            return 'Internal type'
        else:
            return 'Operation Type'

    picking_type_id = fields.Many2one(
        'stock.picking.type', 'Operation Type',
        required=False, readonly=True,
        states={'draft': [('readonly', False)]})
    allow_picking_type_ids = fields.Many2many('stock.picking.type', compute='_compute_allow_picking_type_ids')

    @api.depends('branch_id', 'picking_type_id')
    def _compute_allow_picking_type_ids(self):
        for picking in self:
            domain = picking._domain_picking_Id(picking.branch_id.id)
            picking.allow_picking_type_ids = self.env['stock.picking.type'].search(domain)


    movement_type_value = fields.Char(related='picking_type_id.movement_type_id.value', name='Movement type')
    account_book_id = fields.Many2one('account.accounting.book', string='Accounting Book')
    purchase_order_id = fields.Many2one('purchase.order', name='Purchase_order', copy=False)
    date_trx = fields.Datetime(name='Transaction Date', default=fields.Datetime.now)
    date_list = fields.Datetime(name='Date', default=fields.Datetime.now)
    signed = fields.Char(name='Signed')
    partner_address = fields.Char(name='Partner address')
    default_picking_type_code = fields.Char(store=False)
    reference_ids = fields.Many2many('account.move.line', string="Reference account move line", check_company=True
                                     ,domain="['|', ('company_id', '=', False), ('company_id', '=', company_id), '|', ('branch_id', '=', False), ('branch_id', '=', branch_id)]"
                                     ,readonly=True
                                     ,states={'draft': [('readonly', False)]})

    # disable copy
    date = fields.Datetime(
        'Accounting date', required=True, copy=False,
        default=fields.Datetime.now, index=True, tracking=True,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        help="Accounting date")

    origin = fields.Char(
        'Source Document', index=True, copy=False,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        help="Reference of the document")

    purchase_id = fields.Many2one('purchase.order', related='move_lines.purchase_line_id.order_id',
                                  string="Purchase Orders", readonly=True, copy=False)

    sale_id = fields.Many2one(related="group_id.sale_id", string="Sales Order", store=True, readonly=False, copy=False)

    @api.depends('partner_id')
    def _compute_order_id_domain(self):
        for rec in self:
            rec.order_id_domain = '[("company_id", "=", '+str(rec.company_id.id) + '), ' +\
                                  '("partner_id", "=", '+str(rec.partner_id.id)+')]'

    order_id_domain = fields.Char(compute=_compute_order_id_domain, store=False)

    # branch_id and move_type for T-
    @api.onchange('branch_transfer_id')
    def _onchange_branch_transfer_id(self):
        return {
            'domain': {
                'picking_type_transfer_id': [('branch_id', '=', self.branch_transfer_id.id),
                                  ('movement_type_id.value', '=', 'T+'),
                                  ('active', '=', True)]
            }
        }

    def _domain_branch_transfer_id(self):
        return [('company_id', '=', self.env.company.id),
                ('active', '=', True),
                ('department_level.value', 'in',
                 ['company', 'subsidiary', 'branch'])]

    branch_transfer_id = fields.Many2one('hr.department', string='Transfer to branch', domain=_domain_branch_transfer_id,
                                help='Branch for transfer company, branch')
    picking_type_transfer_id = fields.Many2one(
        'stock.picking.type', 'Operation Type', domain=_onchange_branch_transfer_id,
        states={'draft': [('readonly', False)]})

    internal_picking_id = fields.Many2one('stock.picking', name='Internal Transfer')

    @api.depends('internal_picking_id')
    def _has_internal_picking(self):
        if self.internal_picking_id:
            self.has_internal_picking = True
        else:
            self.has_internal_picking = False

    has_internal_picking = fields.Boolean(store=False, compute='_has_internal_picking')
    transfer_order_no = fields.Char(name='Transfer Order No')
    belong_to = fields.Char(name='Belong To')
    courier_id = fields.Many2one('res.users', name='Courier')

    @api.depends('branch_id')
    def _get_domain_location_branch_id(self):
        branch_id = False
        if self.branch_id.id:
            branch_id = self.branch_id.id
        else:
            branch_id = self.env.user.employee_id.branch_id.id
        return [('company_id', '=', self.env.company.id),
                ('active', '=', True),
                ('usage', '=', 'internal'),
                ('branch_id', '=', branch_id)]

    @api.depends('branch_id')
    def _compute_allow_stock_location_ids(self):
        for picking in self:
            domain = picking._get_domain_location_branch_id()
            picking.allow_stock_location_ids = self.env['stock.location'].search(domain)

    allow_stock_location_ids = fields.Many2many('stock.location', compute='_compute_allow_stock_location_ids')

    location_id = fields.Many2one(
        'stock.location', "Source Location",
        default=lambda self: self.env['stock.picking.type'].browse(
            self._context.get('default_picking_type_id')).default_location_src_id,
        check_company=True, readonly=True, required=False,
        states={'draft': [('readonly', False)]})
    location_dest_id = fields.Many2one(
        'stock.location', "Destination Location",
        default=lambda self: self.env['stock.picking.type'].browse(
            self._context.get('default_picking_type_id')).default_location_dest_id,
        check_company=True, readonly=True, required=False,
        states={'draft': [('readonly', False)]})

    department_id = fields.Many2one('hr.department', name='Department',default=lambda s: s.env.user.department_id)
    # mrp_production_id = fields.Many2one('mrp.production', name='Mrp Production')
    serial = fields.Char(name='Serial')
    receiver = fields.Char(name='Receiver')
    relate_doc = fields.Char(name='Relate doc')
    account_contract_id = fields.Many2one('account.contract', name='Account Contract')
    shipping_method = fields.Selection([('motorbike', 'Motorbike'), ('car', 'Car'), ('truck', 'Truck')],
                                       'Shipping method', default='motorbike')
    about = fields.Char(name='About')
    # Hidden field

    account_move_count = fields.Integer(compute='_compute_account_move', string='Journal Entries count', default=0)

    @api.depends('move_line_ids.state',
                 'move_ids_without_package.state',
                 'move_ids_without_package.account_move_ids', )
    def _compute_account_move(self):
        for pickings in self:
            self.account_move_count = len(pickings.account_move_ids)

    # Right side
    @api.onchange('branch_id')
    def _onchange_branch_id(self):
        for rec in self:
            if rec.branch_id:
                for move in rec.move_lines:
                    move.branch_id = rec.branch_id
                    move.department_id = False
                    move.picking_type_id = False
                    move.location_id = False
                    move.location_dest_id = False
                if rec.department_id.parent_id.id != rec.branch_id.id:
                    rec.department_id = False
                    rec.picking_type_id = False
                    rec.location_id = False
                    rec.location_dest_id = False
                return {
                    'domain': {
                        'department_id': [('company_id', '=', rec.company_id.id),
                                          ('parent_id', '=', rec.branch_id.id),
                                          ('active', '=', True),
                                          ('department_level.value', 'in',
                                           ['department', 'office', 'center', 'team', 'factory'])
                                          ],
                        'picking_type_id': self._domain_picking_Id(branch_id=self.branch_id.id),
                        'location_id': self._get_domain_location_branch_id(),
                        'location_dest_id': self._get_domain_location_branch_id(),
                    }
                }
    # @api.onchange('account_book_id', 'department_id', 'account_contract_id',
    #               'partner_id', 'location_id', 'location_dest_id')
    # def _onchange_branch_id(self):

    @api.onchange('account_book_id')
    def _onchange_account_book_id(self):
        for move in self.move_lines:
            move.account_book_id = self.account_book_id

    @api.onchange('department_id')
    def _onchange_department_id(self):
        for move in self.move_lines:
            move.department_id = self.department_id

    @api.onchange('account_contract_id')
    def _onchange_account_contract_id(self):
        for move in self.move_lines:
            if not move.account_contract_id:
                move.account_contract_id = self.account_contract_id

    def set_default_purchase(self, picking, move, allow_purchase_ids, allow_sale_ids):
        if move.purchase_id.partner_id != picking.partner_id:
            move.purchase_id = False
            move.allow_purchase_ids = allow_purchase_ids
            move.allow_sale_ids = allow_sale_ids
        if move.purchase_line_id.partner_id != picking.partner_id:
            move.purchase_line_id = False
            move.allow_purchase_ids = allow_purchase_ids
            move.allow_sale_ids = allow_sale_ids
        if move.sale_id.partner_id != picking.partner_id:
            move.sale_id = False
            move.allow_purchase_ids = allow_purchase_ids
            move.allow_sale_ids = allow_sale_ids
        if move.sale_line_id.order_partner_id != picking.partner_id:
            move.sale_line_id = False
            move.allow_purchase_ids = allow_purchase_ids
            move.allow_sale_ids = allow_sale_ids

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for picking in self:
            partner_id = picking.partner_id.ids
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'sale'),
                      # ('branch_id', '=', branch_id),
                      ('partner_id', 'in', partner_id)]
            allow_sale_ids = self.env['sale.order'].search(domain)
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'purchase'),
                      # ('branch_id', '=', branch_id),
                      ('partner_id', 'in', partner_id)]
            allow_purchase_ids = self.env['purchase.order'].search(domain)

            for move in picking.move_ids_without_package:
                self.set_default_purchase(picking, move, allow_purchase_ids, allow_sale_ids)
            for move in picking.move_lines:
                self.set_default_purchase(picking, move, allow_purchase_ids, allow_sale_ids)
        for move in self.move_lines:
            move.partner_id = self.partner_id

    @api.onchange('location_id')
    def _onchange_location_id(self):
        for move in self.move_lines:
            move.location_id = self.location_id

    @api.onchange('location_dest_id')
    def _onchange_location_dest_id(self):
        for move in self.move_lines:
            move.location_dest_id = self.location_dest_id

    def _domain_branch_id(self):
        return [('company_id', '=', self.env.company.id),
                ('active', '=', True),
                # ('id', 'in', self.env.user.employee_id.branch_id.ids),
                ('department_level.value', 'in',
                 ['company', 'subsidiary', 'branch'])]

    branch_id = fields.Many2one('hr.department', string='Branch', domain=_domain_branch_id, required=False,
                                # default=lambda s: s.env.user.employee_id.branch_id,
                                help='Leave this field empty if this record is shared between branches')
    stock_move_line = fields.One2many('stock.move.line', 'picking_id', 'Operations detail',
                                      domain=['|', ('package_level_id', '=', False),
                                              ('picking_type_entire_packs', '=', False)])
    account_move_ids = fields.One2many('account.move', 'picking_id')
    account_move_line_ids = fields.One2many('account.move.line', 'picking_id')

    #Addition info tab
    is_print_list = fields.Boolean(string='Print with the list')
    no = fields.Char(string='No')
    good_name = fields.Char(string='Name of goods')
    #date

    @api.model
    def default_get(self, fields_list):
        res = super(StockPicking, self).default_get(fields_list)
        res['branch_id'] = self.env.user.employee_id.branch_id
        if 'default_picking_type_code' in self._context.keys():
            res['default_picking_type_code'] = self._context['default_picking_type_code']
        return res

    @api.constrains('account_book_id', 'picking_type_id', 'date', 'location_dest_id', 'location_id')
    def check_not_null(self):
        for rec in self:
            # if 'account_book_id' not in rec or not rec['account_book_id']:
            #     _logger.error('VLD00072 Sổ hạch toán chưa được chọn giá trị.')
            #     raise ValidationError('Sổ hạch toán chưa được chọn giá trị.')
            if 'name' not in rec or not rec['name']:
                _logger.error('VLD00067 ' + _('Name is required.'))
                raise ValidationError(_('Name is required.'))
            if 'picking_type_id' not in rec or not rec['picking_type_id']:
                if 'incoming' == self._context['default_picking_type_code']:
                    _logger.error('VLD00029' + _('Operation type is required.'))
                    raise ValidationError(_('Operation type is required.'))
                if 'outgoing' == self._context['default_picking_type_code']:
                    _logger.error('VLD00030' + _('Operation type is required.'))
                    raise ValidationError(_('Operation type is required.'))
                if 'internal' == self._context['default_picking_type_code']:
                    _logger.error('VLD00139'+_('Operation type is required.'))
                    raise ValidationError(_('Operation type is required.'))
            if 'date' not in rec or not rec['date']:
                _logger.error('VLD00046' + _('Date is required'))
                raise ValidationError(_('Date is required'))
            if 'location_dest_id' not in rec or not rec['location_dest_id']:
                _logger.error('VLD00025' + _('Location destination is required.'))
                raise ValidationError(_('Location destination is required.'))
            if 'location_id' not in rec or not rec['location_id']:
                _logger.error('VLD00026' + _('Location destination is required.'))
                raise ValidationError(_('Location destination is required.'))

    def set_value_for_move_line(self, vals):
        arr_default_field = ['branch_id', 'account_book_id', 'department_id', 'account_contract_id', 'date',
                             'partner_id', 'location_id', 'location_dest_id', 'picking_type_id', 'default_picking_type_code']
        if 'move_ids_without_package' in vals:
            for move in vals['move_ids_without_package']:
                if move[0] == 0:
                    self.set_value_by_key(vals, move, arr_default_field)

    def set_value_by_key(self, vals, move, keys):
        for key in keys:
            if key not in move[2] or not move[2][key]:
                if key in vals:
                    if key == 'default_picking_type_code':
                        move[2].update({'in_out_type': self.get_in_out_type(default_picking_type_code=vals[key])})
                    else:
                        move[2].update({key: vals[key]})
                elif hasattr(self, key):
                    if key == 'default_picking_type_code':
                        move[2].update({'in_out_type': self.get_in_out_type(default_picking_type_code=getattr(self, key))})
                    else:
                        move[2].update({key: getattr(self, key)})

    @api.model
    def create(self, vals):
        res = None
        self.set_value_for_move_line(vals)
        picking_type = self.env['stock.picking.type'].browse(vals['picking_type_id'])
        name = None
        if 'name' in vals:
            name = vals['name']
        else:
            if picking_type.code in ['incoming', 'outgoing', 'internal']:
                name = self.env['ir.sequence'].next_by_code('stock.picking.' + picking_type.code + '.sequence')
        if name:
            arr_name = name.split('/')
            if arr_name[len(arr_name) - 1] and len(arr_name[len(arr_name) - 1]) > 5:
                _logger.error('VLD00069' + _('Name is too long'))
                raise ValidationError(_('Name is too long'))
            vals.update({'name': name})
        try:
            res = super(StockPicking, self).create(vals)
            if res:
                if res.move_lines:
                    for move_line in res.move_lines:
                        move_line.write({'date': res.date})
                if res.move_line_ids:
                    for stock_move_line in res.move_line_ids:
                        stock_move_line.write({'date': res.date})
        except IntegrityError as e:
            if 'stock_picking_name_uniq' in e.args[0]:
                _logger.error('VLD00068' + _('Reference must be unique per company!'))
                raise ValidationError(_('Reference must be unique per company!'))
            else:
                raise ValidationError('Error Code: '+e.pgcode)
        _logger.info('APP00001')
        return res

    def validate_quantity(self):
        for picking in self:
            products_without_lots = picking.env['product.product']
            is_available = True
            quantity_move_line = {}
            for move_line in picking.move_line_ids:
                if move_line.location_id.id not in quantity_move_line.keys():
                    quantity_move_line.update({move_line.location_id.id: {}})
                location_quantity = quantity_move_line.get(move_line.location_id.id)
                if move_line.package_id.id not in location_quantity.keys():
                    location_quantity.update({move_line.package_id.id: {}})
                package_quantity = location_quantity.get(move_line.package_id.id)
                if move_line.lot_id.id not in package_quantity.keys():
                    package_quantity.update({move_line.lot_id.id: 0})
                quantity = package_quantity.get(move_line.lot_id.id) + move_line.qty_done - move_line.product_uom_qty
                package_quantity.update({move_line.lot_id.id: quantity})
            # Check quantity
            for move_line in picking.move_line_ids:
                quantity_available = move_line.move_id._get_available_quantity(move_line.location_id, move_line.lot_id,
                                                                               move_line.package_id,
                                                                               strict=True)
                deliver_quantity = quantity_move_line.get(move_line.location_id.id).get(move_line.package_id.id) \
                    .get(move_line.lot_id.id)
                if quantity_available < deliver_quantity:
                    products_without_lots |= move_line.product_id
                    is_available = False
            if not is_available:
                msg = _('You cannot delivery more than available quantity. : %s.') % ', '.join(
                    products_without_lots.mapped('display_name'))
                _logger.error(msg)
                raise ValidationError(msg)

    # Before action done
    def _pre_action_done_hook(self):
        # OVERRIDE
        self.check_cost_type_method()
        if not self.env.context.get('skip_immediate'):
            pickings_to_immediate = self._check_immediate()
            if pickings_to_immediate:
                return pickings_to_immediate._action_generate_immediate_wizard(
                    show_transfers=self._should_show_transfers())
        # Validate quantity
        if not self.env.company.is_delivery_more_than_available and self.picking_type_id.code in ['outgoing']:
            self.validate_quantity()
        if not self.env.context.get('skip_backorder'):
            pickings_to_backorder = self._check_backorder()
            if pickings_to_backorder:
                return pickings_to_backorder._action_generate_backorder_wizard(
                    show_transfers=self._should_show_transfers())
        return True

    def check_cost_type_method(self):
        product_specific = []
        precision_digits = self.env['decimal.precision'].precision_get('Product Unit of Measure')
        for picking in self:
            for move_line in picking.move_line_ids:
                # if move_line.product_id.cost_method == 'specific':
                if move_line.product_id.cost_method == 'specific' and move_line.state not in ('done', 'cancel') \
                        and float_is_zero(move_line.qty_done, precision_digits=precision_digits):
                    if move_line.product_id.name not in product_specific:
                        product_specific.append(move_line.product_id.name)
        if len(product_specific) > 0:
            raise UserError(
                _("Product's cost type method is specific please choose lots/serial quantity: %s.") % ', '.join(
                    product_specific))

    # action for button view journal entity
    def action_view_account(self):
        result = self.env["ir.actions.actions"]._for_xml_id('account.action_move_journal_line')
        account_move_ids = self.account_move_ids
        if not account_move_ids or len(account_move_ids) > 0:
            result['domain'] = "[('id','in',%s)]" % account_move_ids.ids
        return result

    # log
    def write(self, vals):
        self.set_value_for_move_line(vals)
        res = super(StockPicking, self).write(vals)
        if res:
            if self.move_lines:
                for move_line in self.move_lines:
                    move_line.write({'date': self.date})
            if self.move_line_ids:
                for stock_move_line in self.move_line_ids:
                    stock_move_line.write({'date': self.date})
        if res is True:
            _logger.info("APP00002")
        return res

    def unlink(self):
        res = super(StockPicking, self).unlink()
        if res is True:
            _logger.info("APP00003")
        return res

    def button_validate(self):
        if not self.date_done and self.picking_type_id.movement_type_id.value == 'T-':
            raise ValidationError(_('Date of transfer is required.'))
        res = super(StockPicking, self).button_validate()
        # if picking type = T- insert receipt note to location_id with type T+ Pending
        if res is True:
            if self.movement_type_value == 'T-':
                data = self.copy_data()
                vals = data[0]
                if not vals['picking_type_transfer_id']:
                    _logger.error(_('Operation type of receipt not found'))
                    raise ValidationError(_('Operation type of receipt not found'))
                name = self.env['ir.sequence'].next_by_code(
                    'stock.picking.incoming.sequence')
                vals.update({'company_id': self.picking_type_transfer_id.default_location_dest_id.company_id.id,
                             'branch_id': self.branch_transfer_id.id,
                             'picking_type_id': self.picking_type_transfer_id.id,
                             'department_id': None,
                             'name': name,
                             'location_id': self.picking_type_transfer_id.default_location_src_id.id,
                             'location_dest_id': self.picking_type_transfer_id.default_location_dest_id.id,
                             'internal_picking_id': self.id,
                             'sale_id': False,
                             'purchase_id': False,
                             'scheduled_date': self.date,
                             'date_trx': self.date,
                             'signed': False,
                             'serial': False,
                             'date': self.date})
                for move in vals['move_lines']:
                    if len(move) != 3:
                        continue
                    move[2].update({
                        'company_id': self.picking_type_transfer_id.default_location_dest_id.company_id.id,
                        'branch_id': self.branch_transfer_id.id,
                        'picking_type_id': self.picking_type_transfer_id.id,
                        'department_id': None,
                        'sale_id': False,
                        'sale_line_id': False,
                        'purchase_id': False,
                        'purchase_line_id': False,
                        'procure_method': 'make_to_stock',
                        'in_out_type': 'in'
                    })
                internal_picking = super(StockPicking, self).create(vals)
                if internal_picking:
                    for move_line in internal_picking.move_lines:
                        move_line.write({'date': internal_picking.date})
                    for stock_move_line in internal_picking.move_line_ids:
                        stock_move_line.write({'date': internal_picking.date})
                self.env['stock.picking'].browse(self.id) \
                    .update({'internal_picking_id': internal_picking.id})

            if self.movement_type_value in ['I-', 'I1-', 'I2-']:
                picking_type_in = parent_id = in_out_picking = None
                if self.picking_type_id and self.picking_type_id.parent_id:
                    parent_id = self.env['stock.picking.type'].search([('id', '=', self.picking_type_id.parent_id.id)])
                if parent_id:
                    in_out_picking = self.env['stock.picking.type'].search([('parent_id', '=', parent_id.id)])
                if in_out_picking:
                    picking_type_ids = in_out_picking.filtered(lambda x: x.code == 'incoming')
                if not picking_type_ids:
                    _logger.error(_('Operation type of receipt not found'))
                    raise ValidationError(_('Operation type of receipt not found'))
                picking_type_in = picking_type_ids[0]
                data = self.copy_data()
                vals = data[0]
                name = self.env['ir.sequence'].next_by_code(
                    'stock.picking.incoming.sequence')
                vals.update({'picking_type_id': picking_type_in.id,
                             'name': name,
                             'location_id': picking_type_in.default_location_src_id.id,
                             'location_dest_id': picking_type_in.default_location_dest_id.id,
                             'sale_id': False,
                             'purchase_id': False,
                             'scheduled_date': self.date,
                             'date_trx': self.date,
                             'signed': False,
                             'serial': False,
                             'date': self.date,
                             'internal_picking_id': self.id})
                for move in vals['move_lines']:
                    if len(move) != 3:
                        continue
                    move[2].update({
                        'picking_type_id': picking_type_in.id,
                        'sale_id': False,
                        'sale_line_id': False,
                        'purchase_id': False,
                        'purchase_line_id': False,
                        'procure_method': 'make_to_stock',
                        'in_out_type': 'in'
                    })
                internal_picking = super(StockPicking, self).create(vals)
                # internal_picking.write({'state': 'done'})
                # super(StockPicking, self).action_confirm()
                # for move in internal_picking.move_lines:
                #     move.update({'quantity_done': move.product_uom_qty})
                # for move_line in internal_picking.move_line_ids:
                #     move_line.sudo().update({'product_qty': move_line.qty_done})
                # super(StockPicking, self)._action_done()
                if internal_picking:
                    for move_line in internal_picking.move_lines:
                        move_line.write({'date': internal_picking.date})
                    for stock_move_line in internal_picking.move_line_ids:
                        stock_move_line.write({'date': internal_picking.date})
                self.env['stock.picking'].browse(self.id) \
                    .update({'internal_picking_id': internal_picking.id})

            if self.move_lines:
                for stock_move in self.move_lines:
                    stock_move.write({'date': self.date})
            if self.move_line_ids:
                for stock_move_line in self.move_line_ids:
                    stock_move_line.write({'date': self.date})
            _logger.info("APP00044")
        return res

    def action_cancel(self):
        res = super(StockPicking, self).action_cancel()
        if res:
            _logger.info("APP00054")
        return res

    purchase_order_ids = fields.Many2many('purchase.order.line', 'stock_move', 'picking_id',
                                          'purchase_line_id', store=False)

    sale_order_ids = fields.Many2many('sale.order.line', 'stock_move', 'picking_id',
                                      'sale_line_id', store=False)

    allow_purchase_order_ids = fields.Many2many('purchase.order.line', compute='_compute_allow_purchase_order_ids')

    @api.depends('partner_id')
    def _compute_allow_purchase_order_ids(self):
        for picking in self:
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'purchase'),
                      # ('branch_id', '=', branch_id),
                      ('remain_quantity', '>', 0),
                      ('order_id.partner_id', 'in', picking.partner_id.ids)]
            picking.allow_purchase_order_ids = self.env['purchase.order.line'].search(domain)

    allow_sale_order_ids = fields.Many2many('sale.order.line', compute='_compute_allow_sale_order_ids')

    @api.depends('partner_id')
    def _compute_allow_sale_order_ids(self):
        for picking in self:
            domain = [('company_id', '=', self.env.company.id), ('state', '=', 'sale'),
                      # ('branch_id', '=', branch_id),
                      ('remain_quantity', '>', 0),
                      ('order_id.partner_id', 'in', picking.partner_id.ids)]
            picking.allow_sale_order_ids = self.env['sale.order.line'].search(domain)

    @api.onchange('purchase_order_ids', 'sale_order_ids')
    def after_choose_from_order(self):
        order_line_ids = arr_exist_order_line_ids = []
        is_sale = False
        if self.picking_type_code == 'incoming':
            order_line_ids = self.purchase_order_ids
            arr_exist_order_line_ids = self.move_ids_without_package.purchase_line_id.ids
        if self.picking_type_code in ['outgoing', 'internal']:
            order_line_ids = self.sale_order_ids
            arr_exist_order_line_ids = self.move_ids_without_package.sale_line_id.ids
            is_sale = True
        if not order_line_ids:
            return False
        arr_move_line = []
        for order_line_item in order_line_ids:
            if ((not is_sale and order_line_item.product_uom_qty > order_line_item.qty_received) or \
                (is_sale and order_line_item.product_uom_qty > order_line_item.qty_delivered)) and \
                    order_line_item.id.origin not in arr_exist_order_line_ids:
                partner_id = False
                if self.partner_id.id:
                    partner_id = self.partner_id.id
                else:
                    partner_id = order_line_item.order_id.partner_id.id
                val = {
                    'product_uom': order_line_item.product_id.uom_id.id,
                    'location_id': self.location_id.id,
                    'location_dest_id': self.location_dest_id.id,
                    'origin': order_line_item.order_id.name,
                    'name': 'New',
                    'product_id': order_line_item.product_id.id,
                    'procure_method': 'make_to_stock',
                    'picking_type_id': self.picking_type_id.id,
                    'warehouse_id': self.picking_type_id.warehouse_id.id,
                    'branch_id': self.branch_id.id,
                    'department_id': self.department_id.id,
                    'picking_id': self.id,
                    'state': self.state,
                    'partner_id': partner_id
                }
                if is_sale:
                    val.update({'sale_line_id': order_line_item.id.origin})
                    val.update({'sale_id': order_line_item.order_id.id})
                    val.update({'product_uom_qty': order_line_item.product_uom_qty - order_line_item.qty_delivered})
                    val.update({'sell_price_unit': order_line_item.price_unit})
                    val.update({'amount_sell': (order_line_item.product_uom_qty - order_line_item.qty_delivered) * order_line_item.price_unit})
                else:
                    val.update({'purchase_line_id': order_line_item.id.origin})
                    val.update({'purchase_id': order_line_item.order_id.id})
                    val.update({'product_uom_qty': order_line_item.product_uom_qty - order_line_item.qty_received})
                arr_move_line.append((0, 0, val))
        self.move_ids_without_package = arr_move_line
        _logger.info("APP00011 " + _("Choose order success"))

    def _create_backorder(self):
        # OVERRIDE
        """ This method is called when the user chose to create a backorder. It will create a new
        picking, the backorder, and move the stock.moves that are not `done` or `cancel` into it.
        """
        # set new document name for backorder
        name = '/'
        if self.picking_type_code in ['incoming', 'outgoing', 'internal']:
            name = self.env['ir.sequence'].next_by_code('stock.picking.' + self.picking_type_code + '.sequence')

        backorders = self.env['stock.picking']
        for picking in self:
            moves_to_backorder = picking.move_lines.filtered(lambda x: x.state not in ('done', 'cancel'))
            if moves_to_backorder:
                backorder_picking = picking.copy({
                    'name': name,
                    'move_lines': [],
                    'move_line_ids': [],
                    'backorder_id': picking.id
                })
                picking.message_post(
                    body=_(
                        'The backorder <a href=# data-oe-model=stock.picking data-oe-id=%d>%s</a> has been created.') % (
                             backorder_picking.id, backorder_picking.name))
                moves_to_backorder.write({'picking_id': backorder_picking.id})
                moves_to_backorder.mapped('package_level_id').write({'picking_id': backorder_picking.id})
                moves_to_backorder.mapped('move_line_ids').write({'picking_id': backorder_picking.id})
                backorders |= backorder_picking
        return backorders

    def search_read(self, cr, uid, domain=None, fields=None, offset=0, limit=None, order=None, context=None):
        domain = cr
        for d in domain:
            if d[0] == 'date' and d[1] == '=' and len(d[2].split(' ')[0]) == 10:
                date = datetime.strptime(d[2].split(' ')[0], "%Y-%m-%d") + timedelta(days=1)
                d[1] = '>='
                d[2] = datetime.combine(date, time(0, 0, 0)).strftime("%Y-%m-%d %H:%M:%S")
                domain += [['date', '<=',
                            datetime.combine(date, time(23, 59, 59)). strftime("%Y-%m-%d %H:%M:%S")]]
                break
        res = super(StockPicking, self).search_read(
            domain, fields, offset, limit, order)
        return res
