from odoo import models, api, fields, _
from odoo.tools import float_compare, float_is_zero


class StockInventory(models.Model):
    _inherit = "stock.inventory"

    def _domain_department_id(self):
        branch_id = self.branch_id.id if self.branch_id else self.env.user.employee_id.branch_id.id
        return [('company_id', '=', self.env.company.id),
                ('parent_id', '=', branch_id),
                ('active', '=', True)
                ]

    accounting_date = fields.Date(
        'Accounting Date',
        help="Date at which the accounting entries will be created"
             " in case of automated inventory valuation."
             " If empty, the inventory date will be used.", default=fields.Date.today())
    name = fields.Char(
        'Inventory Reference', default=_('New'),
        readonly=True, required=True)
    account_book_id = fields.Many2one("account.accounting.book", "Accounting Book",
                                      domain="[('active', '=', True)]",
                                      readonly=True, required=False,
                                      states={'draft': [('readonly', False)]})
    company_id = fields.Many2one('res.company', required=True, readonly=True, default=lambda self: self.env.company)
    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                domain="[('company_id', '=', company_id), ('active', '=', True), ('department_level.value', 'in', ['company', 'subsidiary', 'branch'])]",
                                required=True,
                                readonly=True,
                                states={'draft': [('readonly', False)]})
    department_id = fields.Many2one('hr.department', default=lambda self: self.env.user.employee_id.department_id,
                                    domain=_domain_department_id, required=True,
                                    readonly=True,
                                    states={'draft': [('readonly', False)]})
    participant_ids = fields.One2many('stock.inventory.participants', 'inventory_id', string="Participants", copy=False,
                                      readonly=False,
                                      states={'done': [('readonly', True)]})
    product_ids = fields.Many2many(
        'product.product', string='Products', check_company=True,
        domain="[('type', '=', 'product'), '|', ('company_id', '=', False), ('company_id', '=', company_id), '|', ('branch_id', '=', False), ('branch_id', '=', branch_id)]",
        readonly=True,
        states={'draft': [('readonly', False)]},
        help="Specify Products to focus your inventory on particular Products.")

    @api.onchange('branch_id')
    def _onchange_branch_id(self):
        for rec in self:
            if rec.branch_id:
                if rec.department_id.parent_id.id != rec.branch_id.id:
                    rec.department_id = False
                return {
                    'domain': {
                        'department_id': [('company_id', '=', rec.company_id.id),
                                          ('parent_id', '=', rec.branch_id.id),
                                          ('active', '=', True)],
                    }
                }

    @api.model
    def create(self, values):
        if not values.get('name', False) or values['name'] == _('New'):
            values['name'] = self.env['ir.sequence'].next_by_code('stock.inventory.sequence') or _('New')
        res = super(StockInventory, self).create(values)
        return res

    def action_open_inventory_lines(self):
        self.ensure_one()
        action = {
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'name': _('Inventory Lines'),
            'res_model': 'stock.inventory.line',
        }
        context = {
            'default_is_editable': True,
            'default_inventory_id': self.id,
            'default_company_id': self.company_id.id,
            'default_branch_id': self.branch_id.id,
            'default_department_id': self.department_id.id
        }
        # Define domains and context
        domain = [
            ('inventory_id', '=', self.id),
            ('location_id.usage', 'in', ['internal', 'transit'])
        ]
        if self.location_ids:
            context['default_location_id'] = self.location_ids[0].id
            if len(self.location_ids) == 1:
                if not self.location_ids[0].child_ids:
                    context['readonly_location_id'] = True

        if self.product_ids:
            # no_create on product_id field
            action['view_id'] = self.env.ref('stock.stock_inventory_line_tree_no_product_create').id
            if len(self.product_ids) == 1:
                context['default_product_id'] = self.product_ids[0].id
        else:
            # no product_ids => we're allowed to create new products in tree
            action['view_id'] = self.env.ref('stock.stock_inventory_line_tree').id

        action['context'] = context
        action['domain'] = domain
        return action


class InventoryLine(models.Model):
    _inherit = 'stock.inventory.line'

    @api.model
    def _domain_product_id(self):
        if self.env.context.get('active_model') == 'stock.inventory':
            inventory = self.env['stock.inventory'].browse(self.env.context.get('active_id'))
            if inventory.exists() and len(inventory.product_ids) > 1:
                return "[('type', '=', 'product'), '|', ('company_id', '=', False), ('company_id', '=', company_id), ('id', 'in', %s)]" % inventory.product_ids.ids
        return "[('type', '=', 'product'), '|', ('company_id', '=', False), ('company_id', '=', company_id), '|', ('branch_id', '=', False), ('branch_id', '=', branch_id)]"

    account_book_id = fields.Many2one("account.accounting.book", "Accounting Book",
                                      domain="[('active', '=', True)]",
                                      readonly=True, required=False,
                                      related='inventory_id.account_book_id',
                                      states={'draft': [('readonly', False)]}, store=True)
    company_id = fields.Many2one('res.company', required=True, readonly=True, default=lambda self: self.env.company)
    branch_id = fields.Many2one('hr.department', string='Branch',
                                default=lambda self: self.env.user.employee_id.branch_id,
                                related='inventory_id.branch_id',
                                required=True, store=True)
    department_id = fields.Many2one('hr.department',
                                    default=lambda self: self.env.user.employee_id.department_id,
                                    related='inventory_id.department_id',
                                    required=True, store=True)

    def _generate_moves(self):
        vals_list = []
        for line in self:
            virtual_location = line._get_virtual_location()
            rounding = line.product_id.uom_id.rounding
            if float_is_zero(line.difference_qty, precision_rounding=rounding):
                continue
            if line.difference_qty > 0:  # found more than expected
                vals = line._get_move_values(line.difference_qty, virtual_location.id, line.location_id.id, False)
            else:
                vals = line._get_move_values(abs(line.difference_qty), line.location_id.id, virtual_location.id, True)
            vals['picking_type_id'] = self._get__picking_type(line)
            vals_list.append(vals)
        return self.env['stock.move'].create(vals_list)

    @api.model
    def _get__picking_type(self, line):
        if line.difference_qty > 0:
            return self.env['stock.picking.type'].search([
                ('code', '=', 'receipt'),
                ('company_id', '=', self.company_id.id),
                ('parent_id', '=', False),
                ('default_location_dest_id', '=', line.location_id.id)
            ], limit=1).id
        elif line.difference_qty < 0:
            return self.env['stock.picking.type'].search([
                ('code', '=', 'delivery'),
                ('company_id', '=', self.company_id.id),
                ('parent_id', '=', False),
                ('default_location_src_id', '=', line.location_id.id)
            ], limit=1).id
