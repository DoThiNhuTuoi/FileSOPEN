# -*- coding: utf-8 -*-


from odoo import models, fields


class StockValuationLayer(models.Model):
    _inherit = 'stock.valuation.layer'

    picking_type_id = fields.Many2one('stock.picking.type', related='stock_move_id.picking_type_id',
                                      store=True)
    branch_id = fields.Many2one('hr.department', name='Branch')
    department_id = fields.Many2one('hr.department', name='Department')
    movement_type = fields.Char(name='Movement_type', related='stock_move_id.movement_type', store=True)
    accounting_date = fields.Datetime(related='stock_move_id.date', store=True)
