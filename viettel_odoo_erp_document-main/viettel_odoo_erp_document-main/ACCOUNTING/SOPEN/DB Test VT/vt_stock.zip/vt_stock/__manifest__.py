# -*- coding: utf-8 -*-

{
    'name': 'Kho',
    'version': '1.0',
    'category': 'Tài chính',
    'sequence': 190,
    'author': 'Viettel IT',

    'summary': """Quản lý kho vận""",

    'description': """- Quản lý tình hình nhập, xuất, tồn kho theo chủng loại, nhóm, chi tiết vật tư, hàng hóa, thành phẩm
- Quản lý chi tiết đến từng kho, hỗ trợ tự động xuất kho theo cách thức xuất kho Nhập trước xuất trước (FIFO),  Nhập sau xuất trước (LIFO), Hết hạn trước xuất trước (FEFO) 
- Hỗ trợ tự động tính giá xuất kho theo 4 phương pháp: Bình quân tức thời, Bình quân cuối kỳ, Đích danh, Nhập trước xuât trước
- Lên các báo cáo kho: Tồn kho, Nhập xuất tồn kho""",

    'feature': """Lệnh sản xuất
- Quản lý và cho phép người dùng tạo Lệnh sản xuất, với chi tiết vật tư cần xuất căn cứ vào định mức vật tư của sản phẩm và theo số lượng sản phẩm cần sản xuất

Lệnh lắp ráp, tháo dỡ
- Cho phép người dùng thực hiện tạo lệnh lắp ráp/tháo dỡ, đồng thời tự động sinh phiếu xuất kho, nhập kho tương ứng

Xuất kho
- Quản lý các phiếu xuất kho vật tư/hàng hóa/thành phẩm

Nhập kho
- Quản lý các phiếu nhập kho vật tư/hàng hóa/thành phẩm

Chuyển kho
- Quản lý các phiếu chuyển kho vật tư/hàng hóa/thành phẩm từ các địa điểm nội bộ của cùng 1 kho hàng

Tính giá xuất kho
- Hỗ trợ tính giá xuất kho cuối kỳ theo 4 phương pháp: Bình quân tức thời sau mỗi lần nhập, Bình quân cuối kỳ, Đích danh, Nhập trước xuất trước

Kiểm kê kho""",

    'website': 'https://viettel.com.vn/',
    'depends': [
        'vt_account_base',
        'vt_stock_base',
        'stock_account',
        'purchase_stock',
        'sale_stock',
        'product_expiry',
        'vt_account_contract',
        'stock_landed_costs',
        'mrp_landed_costs',
        'report_accounting',
        'vt_mrp',
        # 'vt_account_contract_sale',
        # 'vt_account_contract_purchase'
    ],
    'data': [
        'data/stock_picking_data.xml',
        'security/ir.model.access.csv',
        'views/assets.xml',
        'views/stock_menu.xml',
        'views/res_config_settings_views.xml',
        'views/order_views.xml',
        'views/stock_picking_views.xml',
        'views/stock_landed_cost_views.xml',
        'data/stock_landed_cost_data.xml',
        'data/stock_inventory_data.xml',
        'data/period_cost.xml',
        'views/stock_inventory_views.xml',
        'views/stock_calculate_cost.xml',
        'views/res_users_views.xml',
        'reports/report_views.xml',
        'data/jasper_report_template.xml'
    ],
    'demo': [
        'data/stock_demo.xml',
    ],
    "qweb": [],
    'installable': True,
    'application': True
}
