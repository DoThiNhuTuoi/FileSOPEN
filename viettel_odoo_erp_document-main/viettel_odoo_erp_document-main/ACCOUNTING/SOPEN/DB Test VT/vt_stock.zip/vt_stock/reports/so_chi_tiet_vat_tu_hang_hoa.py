from odoo import models, api, fields, _
from odoo.tools.misc import formatLang, DEFAULT_SERVER_DATE_FORMAT

from datetime import timedelta


class SoChiTietVatTuHangHoa(models.AbstractModel):
    _name = 'so.chi.tiet.vat.tu.hang.hoa'
    _description = 'Sổ chi tiết vật tư hàng hóa'
    _inherit = "report.dynamic"

    filter_branch = True
    filter_date = {'mode': 'range', 'filter': 'this_month'}
    filter_location = True
    filter_product_category = True
    filter_product = True

    @api.model
    def _get_report_name(self, options=None):
        return _('Sổ chi tiết vật tư hàng hóa')

    def get_csv_fields(self, options):
        return []

    def get_csv_rows(self, options):
        return self._get_data_csv(options)

    @api.model
    def open_journal_items_window(self, account):
        return {}

    @api.model
    def _get_columns_name(self, options):
        columns_names = []
        return columns_names

    def _get_data(self, options):
        data = []
        return data

    @api.model
    def _query_get(self, options):
        return ""

    def _get_lines(self, options):
        lines = []
        return lines
