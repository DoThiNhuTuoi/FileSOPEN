from odoo import _, models, fields


class ReturnPickingLine(models.TransientModel):
    _inherit = "stock.return.picking.line"

    account_book_id = fields.Many2one('account.accounting.book', string='Accounting Book', store=True)
    branch_id = fields.Many2one('hr.department', name='Branch', store=True)
    department_id = fields.Many2one('hr.department', name='Department', store=True)
    account_contract_id = fields.Many2one('account.contract', name='Contract', store=True)


class ReturnPicking(models.TransientModel):
    _inherit = 'stock.return.picking'

    account_book_id = fields.Many2one('account.accounting.book', string='Accounting Book', store=True)
    branch_id = fields.Many2one('hr.department', name='Branch', store=True)
    department_id = fields.Many2one('hr.department', name='Department', store=True)
    account_contract_id = fields.Many2one('account.contract', name='Contract', store=True)

    def _prepare_move_default_values(self, return_line, new_picking):
        res = super(ReturnPicking, self)._prepare_move_default_values(return_line, new_picking)
        if not self.branch_id:
            res.update({'branch_id': self.picking_id.branch_id.id})
        if not self.account_book_id:
            res.update({'account_book_id': self.picking_id.account_book_id.id})
        if not self.department_id:
            res.update({'department_id': self.picking_id.department_id.id})
        if not self.account_contract_id:
            res.update({'account_contract_id': self.picking_id.account_contract_id.id})
        return res
